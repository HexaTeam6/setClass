#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `message` varchar(255) NOT NULL,
  `link` varchar(100) NOT NULL,
  `icon` varchar(40) NOT NULL,
  `color` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('9', '999999999999', 'C028D15CE3', 'Telah menambahkan ruang R-13', 'MasterRuang', 'mdi-home-variant', 'success', '2018-01-04 08:47:08');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('10', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Ketua Kelas', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 08:17:12');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('11', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Sekertaris Absensi', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 08:48:05');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('12', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Sekertaris Absensi', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 08:48:05');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('13', '999999999999', 'C028D15CE3', 'Telah menghapus jabatan Sekertaris Absensi', 'MasterJabatan', 'mdi-ruler', 'danger', '2018-01-07 08:48:16');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('14', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Sekertaris Jurnal', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 08:48:45');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('15', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Bendahara Kas', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 15:00:03');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('16', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Bendahara Tabungan', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 15:00:27');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('17', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Sekertaris Jurnal', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-07 16:01:34');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('18', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Anggota', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-07 16:01:47');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('19', '999999999999', 'C028D15CE3', 'Telah mengkonfirmasiAlex sebagai anggota kelas', 'MasterSiswa', 'mdi-account-check', 'success', '2018-01-07 16:07:40');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('20', '222222222', 'C028D15CE3', 'Telah bergabung ke kelas.', 'MasterSiswa', 'mdi-account-multiple-plus', 'success', '2018-01-07 19:23:03');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('21', '999999999999', 'C028D15CE3', 'Telah mengkonfirmasi Dicky%20Bayu%20Sadewa sebagai anggota kelas', 'MasterSiswa', 'mdi-account-check', 'success', '2018-01-07 19:25:45');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('22', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Ketua Kelas', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-07 19:59:21');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('23', '999999999999', 'C028D15CE3', 'Telah menambahkan ruang Lab-9', 'MasterRuang', 'mdi-home-variant', 'success', '2018-01-07 19:59:51');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('24', '999999999999', 'C028D15CE3', 'Telah menambahkan matapelajaran Bahasa Indonesia', 'MasterMatapelajaran', 'mdi-book-open-page-variant', 'success', '2018-01-07 20:00:06');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('25', '999999999999', 'C028D15CE3', 'Telah mengedit jabatan Sekertaris Absens', 'MasterJabatan', 'mdi-ruler', 'warning', '2018-01-07 20:00:29');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('26', '999999999999', 'C028D15CE3', 'Telah mengedit jabatan Sekertaris Jurnals', 'MasterJabatan', 'mdi-ruler', 'warning', '2018-01-07 20:01:29');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('27', '999999999999', 'C028D15CE3', 'Telah mengedit jabatan Sekertaris Jurnal', 'MasterJabatan', 'mdi-ruler', 'warning', '2018-01-07 20:03:37');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('28', '999999999999', 'C028D15CE3', 'Telah mengedit jabatan Sekertaris Absensi', 'MasterJabatan', 'mdi-ruler', 'warning', '2018-01-07 20:03:53');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('29', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Anggota', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-07 20:16:45');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('30', '999999999999', 'C028D15CE3', 'Telah menghapus Dicky Bayu Sadewa dari anggota kelas', 'MasterSiswa', 'mdi-account-minus', 'danger', '2018-01-07 22:26:48');


#
# TABLE STRUCTURE FOR: logs_detail
#

DROP TABLE IF EXISTS `logs_detail`;

CREATE TABLE `logs_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_logs` int(11) NOT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('6', '9', '111111111', 'C028D15CE3', '2018-01-04 08:47:46');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('7', '10', '111111111', 'C028D15CE3', '2018-01-07 08:50:55');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('8', '12', '111111111', 'C028D15CE3', '2018-01-07 08:51:02');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('9', '11', '111111111', 'C028D15CE3', '2018-01-07 08:51:06');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('10', '13', '111111111', 'C028D15CE3', '2018-01-07 08:51:08');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('11', '14', '111111111', 'C028D15CE3', '2018-01-07 08:51:11');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('12', '15', '111111111', 'C028D15CE3', '2018-01-07 16:08:16');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('13', '16', '111111111', 'C028D15CE3', '2018-01-07 16:08:24');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('14', '19', '111111111', 'C028D15CE3', '2018-01-07 16:08:34');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('15', '18', '111111111', 'C028D15CE3', '2018-01-07 16:08:39');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('16', '17', '111111111', 'C028D15CE3', '2018-01-07 16:08:44');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('17', '20', '999999999999', 'C028D15CE3', '2018-01-07 19:25:31');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('18', '21', '111111111', 'C028D15CE3', '2018-01-07 19:43:09');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('19', '20', '111111111', 'C028D15CE3', '2018-01-07 19:54:06');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('20', '28', '111111111', 'C028D15CE3', '2018-01-07 20:05:40');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('21', '27', '111111111', 'C028D15CE3', '2018-01-07 20:08:51');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('22', '25', '111111111', 'C028D15CE3', '2018-01-07 20:08:57');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('23', '26', '111111111', 'C028D15CE3', '2018-01-07 20:09:08');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('24', '24', '111111111', 'C028D15CE3', '2018-01-07 20:09:13');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('25', '23', '111111111', 'C028D15CE3', '2018-01-07 20:09:17');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('26', '22', '111111111', 'C028D15CE3', '2018-01-07 20:09:24');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('27', '28', '222222222', 'C028D15CE3', '2018-01-07 20:10:25');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('28', '27', '222222222', 'C028D15CE3', '2018-01-07 20:10:29');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('29', '26', '222222222', 'C028D15CE3', '2018-01-07 20:10:32');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('30', '25', '222222222', 'C028D15CE3', '2018-01-07 20:10:36');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('31', '24', '222222222', 'C028D15CE3', '2018-01-07 20:10:39');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('32', '23', '222222222', 'C028D15CE3', '2018-01-07 20:10:43');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('33', '22', '222222222', 'C028D15CE3', '2018-01-07 20:10:46');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('34', '21', '222222222', 'C028D15CE3', '2018-01-07 20:10:51');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('35', '19', '222222222', 'C028D15CE3', '2018-01-07 20:10:59');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('36', '18', '222222222', 'C028D15CE3', '2018-01-07 20:11:03');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('37', '17', '222222222', 'C028D15CE3', '2018-01-07 20:11:07');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('38', '16', '222222222', 'C028D15CE3', '2018-01-07 20:11:12');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('39', '15', '222222222', 'C028D15CE3', '2018-01-07 20:11:15');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('40', '14', '222222222', 'C028D15CE3', '2018-01-07 20:11:19');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('41', '13', '222222222', 'C028D15CE3', '2018-01-07 20:11:23');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('42', '11', '222222222', 'C028D15CE3', '2018-01-07 20:11:27');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('43', '12', '222222222', 'C028D15CE3', '2018-01-07 20:11:31');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('44', '10', '222222222', 'C028D15CE3', '2018-01-07 20:11:35');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('45', '9', '222222222', 'C028D15CE3', '2018-01-07 20:11:39');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('46', '29', '111111111', 'C028D15CE3', '2018-01-07 20:17:20');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('47', '29', '222222222', 'C028D15CE3', '2018-01-07 20:17:58');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('48', '30', '111111111', 'C028D15CE3', '2018-01-07 22:28:00');


#
# TABLE STRUCTURE FOR: master_jabatan
#

DROP TABLE IF EXISTS `master_jabatan`;

CREATE TABLE `master_jabatan` (
  `kode_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `akses_jabatan` int(11) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `jabatan` varchar(40) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_jabatan`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('1', '1', '24101999', 'CEO', 'CEO setClass', '2017-12-10 12:03:22', '2017-12-10 12:03:22');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('2', '2', '204C3DC84B', 'Wali Kelas', 'Wali Kelas', '2017-12-10 12:23:25', '2017-12-10 12:23:30');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('3', '2', 'ED147B54C8', 'Wali Kelas', 'Wali Kelas', '2017-12-10 12:23:58', '2017-12-10 12:23:58');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('4', '3', '204C3DC84B', 'Ketua Kelas', 'Mengkoordinir kelas', '2017-12-10 13:15:40', '2017-12-10 13:15:40');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('5', '4', '204C3DC84B', 'Sekertaris', 'Mengatur administrasi kelas', '2017-12-10 13:26:42', '2017-12-10 13:26:42');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('6', '5', '204C3DC84B', 'Bendahara Kas', 'Mengatur keuangan kas', '2017-12-10 13:27:17', '2017-12-10 14:01:18');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('7', '4', '204C3DC84B', 'Sekertaris Jurnal', 'Mengatur Jurnal', '2017-12-10 13:28:12', '2017-12-10 14:02:19');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('8', '6', '204C3DC84B', 'Anggota', 'Anggota kelas', '2017-12-10 15:12:20', '2017-12-10 15:12:35');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('9', '2', 'C028D15CE3', 'Wali Kelas', 'Wali Kelas', '2017-12-13 20:55:50', '2017-12-13 20:55:50');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('16', '2', '527002B1F3', 'Wali Kelas', 'Wali Kelas', '2017-12-30 18:07:50', '2017-12-30 18:07:50');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('25', '6', 'C028D15CE3', 'Anggota', 'Anggota kelas', '2018-01-01 21:26:50', '2018-01-01 21:26:50');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('26', '3', 'C028D15CE3', 'Ketua Kelas', 'Mengkoordinir kelas', '2018-01-07 08:17:12', '2018-01-07 08:17:12');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('28', '4', 'C028D15CE3', 'Sekertaris Absensi', 'Mengatur absensi kelas', '2018-01-07 08:48:05', '2018-01-07 20:03:53');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('29', '4', 'C028D15CE3', 'Sekertaris Jurnal', 'Mengatur jurnal kelas', '2018-01-07 08:48:45', '2018-01-07 20:03:37');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('30', '5', 'C028D15CE3', 'Bendahara Kas', 'Mengatur kas kelas', '2018-01-07 15:00:03', '2018-01-07 15:00:03');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('31', '5', 'C028D15CE3', 'Bendahara Tabungan', 'Mengatur tabungan kelas', '2018-01-07 15:00:26', '2018-01-07 15:00:26');


#
# TABLE STRUCTURE FOR: master_kelas
#

DROP TABLE IF EXISTS `master_kelas`;

CREATE TABLE `master_kelas` (
  `kode_kelas` varchar(50) NOT NULL,
  `nama_sekolah` varchar(40) NOT NULL,
  `alamat_sekolah` varchar(250) NOT NULL,
  `telp_sekolah` varchar(30) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `jurusan` varchar(40) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('204C3DC84B', 'Smkn 2 Surabaya', 'Jl. Patua', '031123123123', '1 SMA/SMK', 'RPL', '2017-12-03 09:10:44', '2017-12-26 16:57:58');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('527002B1F3', 'Smkn 2 Surabaya', 'Jl. Patua', '03191281723', '3 SMA/SMK', 'Rekayasa Perangkat Lunak', '2017-12-30 18:07:50', '2017-12-30 18:07:50');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('C028D15CE3', 'Smkn 2 Surabaya', 'Jl. Patua', '03191281723', '3 SMA/SMK', 'Rekayasa Perangkat Lunak', '2017-12-13 19:05:00', '2017-12-13 19:05:00');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('ED147B54C8', 'Smkn 2 Surabaya', 'Jl. Patua', '03134753458', '3 SMA/SMK', 'RPL', '2017-12-03 18:50:26', '2017-12-10 10:02:02');


#
# TABLE STRUCTURE FOR: master_login
#

DROP TABLE IF EXISTS `master_login`;

CREATE TABLE `master_login` (
  `kode_user` varchar(50) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_jabatan` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_user`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('111111111', '3', 'C028D15CE3', '25', 'alex@gmail.com', 'Alex', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '5d8f4f81804a6fc9bec063a6dd500747.jpeg', '2018-01-01 22:02:54', '2018-01-07 22:34:35');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('111111111111', '2', '527002B1F3', '16', 'nailmuna@gmail.com', 'Nailil Muna', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '85a64515235d57f04822a7baaf6a3fc5.png', '2017-12-30 18:07:50', '2017-12-31 23:44:39');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('764134813461', '2', 'ED147B54C8', '3', 'suwondo@gmail.com', 'Suwondo', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', 'default-profile.png', '2017-12-03 18:50:26', '2017-12-31 23:44:42');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('909090909090', '2', '204C3DC84B', '2', 'rini@gmail.com', 'Rini Umbarani', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '02f9d51f0b74cf009bad3f976da0f59b.jpg', '2017-12-03 09:10:44', '2017-12-31 23:44:43');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('999999999999', '2', 'C028D15CE3', '9', 'fitriyaningsihida@yahoo.co.id', 'Ida Fitriyaningsih', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '0f856bc17a07c673e657fb996cd7993f.jpg', '2017-12-13 19:05:01', '2017-12-31 23:44:44');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('hexa', '1', '24101999', '1', 'abdurrachmanwahed@gmail.com', 'Abdur Rachman Wahed', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', 'default-profile.png', '2017-11-27 10:16:29', '2017-12-31 23:44:47');


#
# TABLE STRUCTURE FOR: master_matapelajaran
#

DROP TABLE IF EXISTS `master_matapelajaran`;

CREATE TABLE `master_matapelajaran` (
  `kode_matapelajaran` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(50) NOT NULL,
  `nama_matapelajaran` varchar(40) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_matapelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `master_matapelajaran` (`kode_matapelajaran`, `kode_kelas`, `nama_matapelajaran`, `created_at`, `updated_at`) VALUES ('1', 'C028D15CE3', 'Matematika', '2017-12-30 09:59:40', '2017-12-30 10:23:19');
INSERT INTO `master_matapelajaran` (`kode_matapelajaran`, `kode_kelas`, `nama_matapelajaran`, `created_at`, `updated_at`) VALUES ('2', '527002B1F3', 'Matematika', '2018-01-03 20:56:55', '2018-01-03 20:56:55');
INSERT INTO `master_matapelajaran` (`kode_matapelajaran`, `kode_kelas`, `nama_matapelajaran`, `created_at`, `updated_at`) VALUES ('3', 'C028D15CE3', 'Bahasa Indonesia', '2018-01-07 20:00:06', '2018-01-07 20:00:06');


#
# TABLE STRUCTURE FOR: master_ruang
#

DROP TABLE IF EXISTS `master_ruang`;

CREATE TABLE `master_ruang` (
  `kode_ruang` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(50) NOT NULL,
  `nama_ruang` varchar(40) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_ruang`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('2', 'C028D15CE3', 'R-21', '2017-12-30 10:56:43', '2017-12-30 10:56:43');
INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('3', '527002B1F3', 'R -21', '2018-01-03 20:56:01', '2018-01-03 20:56:01');
INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('4', 'C028D15CE3', 'R-13', '2018-01-04 08:47:08', '2018-01-04 08:47:08');
INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('5', 'C028D15CE3', 'Lab-9', '2018-01-07 19:59:51', '2018-01-07 19:59:51');


#
# TABLE STRUCTURE FOR: master_siswa
#

DROP TABLE IF EXISTS `master_siswa`;

CREATE TABLE `master_siswa` (
  `NIS` varchar(20) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `NIK` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`NIS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('111111111', 'C028D15CE3', '3', 'alex@gmail.com', '1111111111111111', 'Alex', 'Laki Laki', 'Surabaya', '1999-10-24', 'Jl. Manukan Kasman No. 1/36', '+628-897-498-1793', '5d8f4f81804a6fc9bec063a6dd500747.jpeg', '2018-01-01 22:02:54', '2018-01-07 22:34:35');


#
# TABLE STRUCTURE FOR: master_wali_kelas
#

DROP TABLE IF EXISTS `master_wali_kelas`;

CREATE TABLE `master_wali_kelas` (
  `NIP` varchar(20) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`NIP`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('111111111111', '527002B1F3', '2', 'nailmuna@gmail.com', 'Nailil Muna', 'Perempuan', 'Surabaya', '1972-01-08', 'Jl. Uka Gang 18', '+628-769-821-7389', '85a64515235d57f04822a7baaf6a3fc5.png', '2017-12-30 18:07:50', '2017-12-30 18:07:50');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('764134813461', 'ED147B54C8', '2', 'suwondo@gmail.com', 'Suwondo', 'Laki Laki', 'Surabaya', '1969-10-18', 'Manukan Kulon', '+628-768-612-3846', '', '2017-12-03 18:50:26', '2017-12-30 08:34:05');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('909090909090', '204C3DC84B', '2', 'rini@gmail.com', 'Rini Umbarani', 'Perempuan', 'Surabaya', '1967-12-20', 'Jl. Simo rukun', '+628-981-231-23', '02f9d51f0b74cf009bad3f976da0f59b.jpg', '2017-12-03 09:10:44', '2017-12-27 21:19:55');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('999999999999', 'C028D15CE3', '2', 'fitriyaningsihida@yahoo.co.id', 'Ida Fitriyaningsih', 'Perempuan', 'Surabaya', '1972-11-25', 'Jl. Kandangan', '+628-871-239-1231', '0f856bc17a07c673e657fb996cd7993f.jpg', '2017-12-13 19:05:01', '2018-01-04 10:22:40');


#
# TABLE STRUCTURE FOR: menu_child
#

DROP TABLE IF EXISTS `menu_child`;

CREATE TABLE `menu_child` (
  `kode_menu_child` int(11) NOT NULL AUTO_INCREMENT,
  `kode_menu_header` int(11) NOT NULL,
  `menu_name` varchar(20) NOT NULL,
  `file_php` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_menu_child`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('4', '1', 'Menu Header', 'MenuHeader', '2017-12-05 21:09:47', '2017-12-05 21:09:47');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('5', '1', 'Menu Child', 'MenuChild', '2017-12-05 21:10:04', '2017-12-05 21:10:04');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('9', '1', 'Hak Akses', 'HakAkses', '2017-12-10 10:11:50', '2017-12-10 10:11:50');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('11', '1', 'Menu Level', 'MenuLevel', '2017-12-11 20:13:47', '2017-12-11 20:13:47');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('12', '1', 'Profil', 'UserProfile', '2017-12-26 11:23:06', '2017-12-26 19:03:02');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('13', '2', 'Master Jabatan', 'MasterJabatan', '2017-12-27 21:35:55', '2017-12-27 21:35:55');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('14', '2', 'Master Matapelajaran', 'MasterMatapelajaran', '2017-12-30 09:47:16', '2017-12-30 09:47:16');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('15', '2', 'Master Ruang', 'MasterRuang', '2017-12-30 10:53:05', '2017-12-30 10:53:05');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('17', '2', 'Master Siswa', 'MasterSiswa', '2018-01-07 06:48:44', '2018-01-07 06:48:44');


#
# TABLE STRUCTURE FOR: menu_hak_akses
#

DROP TABLE IF EXISTS `menu_hak_akses`;

CREATE TABLE `menu_hak_akses` (
  `kode_akses` int(11) NOT NULL AUTO_INCREMENT,
  `hak_akses` varchar(30) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_akses`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('1', 'hexa', 'CEO setClass', '2017-12-10 09:53:28', '2017-12-10 15:57:28');
INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('2', 'Wali Kelas', 'Wali kelas', '2017-12-10 11:08:34', '2017-12-10 15:57:54');
INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('3', 'Siswa', 'Anggota kelas', '2017-12-10 11:11:06', '2017-12-31 14:22:30');
INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('4', 'Orang Tua', 'Orang tua murid', '2017-12-10 15:48:23', '2017-12-10 15:58:20');


#
# TABLE STRUCTURE FOR: menu_header
#

DROP TABLE IF EXISTS `menu_header`;

CREATE TABLE `menu_header` (
  `kode_menu_header` int(11) NOT NULL AUTO_INCREMENT,
  `menu_header` varchar(20) NOT NULL,
  `icon` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_menu_header`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('1', 'Pengaturan', 'fa fa-wrench', '2017-12-04 16:55:32', '2017-12-04 16:55:32');
INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('2', 'Master', 'fa fa-archive', '2017-12-04 16:55:42', '2017-12-04 16:55:42');


#
# TABLE STRUCTURE FOR: menu_level
#

DROP TABLE IF EXISTS `menu_level`;

CREATE TABLE `menu_level` (
  `kode_menu_level` int(11) NOT NULL AUTO_INCREMENT,
  `kode_akses` int(11) NOT NULL,
  `kode_menu_child` int(11) NOT NULL,
  `akses_insert` tinyint(1) NOT NULL,
  `akses_view` tinyint(1) NOT NULL,
  `akses_edit` tinyint(1) NOT NULL,
  `akses_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`kode_menu_level`)
) ENGINE=InnoDB AUTO_INCREMENT=384 DEFAULT CHARSET=latin1;

INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('357', '1', '4', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('358', '1', '5', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('359', '1', '9', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('360', '1', '11', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('361', '1', '12', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('362', '1', '13', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('363', '1', '14', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('364', '1', '15', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('365', '1', '17', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('366', '2', '4', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('367', '2', '5', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('368', '2', '9', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('369', '2', '11', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('370', '2', '12', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('371', '2', '13', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('372', '2', '14', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('373', '2', '15', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('374', '2', '17', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('375', '3', '4', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('376', '3', '5', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('377', '3', '9', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('378', '3', '11', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('379', '3', '12', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('380', '3', '13', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('381', '3', '14', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('382', '3', '15', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('383', '3', '17', '0', '1', '0', '0');


