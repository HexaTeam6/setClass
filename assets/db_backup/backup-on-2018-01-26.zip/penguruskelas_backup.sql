#
# TABLE STRUCTURE FOR: data_informasi
#

DROP TABLE IF EXISTS `data_informasi`;

CREATE TABLE `data_informasi` (
  `id_informasi` int(11) NOT NULL AUTO_INCREMENT,
  `isi_informasi` text NOT NULL,
  `gambar` varchar(100) DEFAULT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `akses_jabatan` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_informasi`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('8', '<p>aaaaaa<strong>aaaaaaaaaaa</strong>aaaaas</p>', 'ecb9c9116be2e65a64384ad797fda0b0.jpeg', '999999999999', 'C028D15CE3', '4', '2018-01-11 21:51:07', '2018-01-12 04:20:24');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('10', '<p>aaaaaaaaaaaaaaaaaaa</p>', '', '999999999999', 'C028D15CE3', '0', '2018-01-14 12:32:58', '2018-01-14 12:32:58');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('11', '<p>aaaaaaaaaaaaaaaaaaaaaaaaaaaa</p>', '', '999999999999', 'C028D15CE3', '3', '2018-01-14 12:33:15', '2018-01-14 12:33:15');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('12', '<p>aaaaaaaaaaaaaaaaaaaaaaaaa</p>', '', '999999999999', 'C028D15CE3', '5', '2018-01-14 12:34:32', '2018-01-14 12:34:32');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('13', '<p>Ini desain <strong>poster&nbsp;untuk kelas</strong>..<br />gimana? ada saran?</p>', 'c0e2e9e9f2e45ed8655a158e8d6b860c.jpg', '999999999999', 'C028D15CE3', '0', '2018-01-14 13:58:43', '2018-01-15 20:55:14');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('14', '<p>tetstafytsaskdjalslgvasfd</p>', '9757af6236a321c3fbf123021a257df5.jpeg', '999999999999', 'C028D15CE3', '3', '2018-01-14 14:03:10', '2018-01-14 14:03:10');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('15', '<p><span style=\"color: #ff0000;\"><strong>Anak anak</strong></span> ini namanya spedo meter..<br />diharap anak anak bisa mendesain sedemikian rupa..</p>', '7aaf7ce97f7b7eb7a2b8a6f5aeeec65d.png', '999999999999', 'C028D15CE3', '0', '2018-01-15 21:03:10', '2018-01-15 21:03:10');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('16', '<p>Contoh surat ..</p>', 'e2174ac8fb4ecee0e2a3e83e1324a1df.jpg', '111111111', 'C028D15CE3', '0', '2018-01-15 21:15:38', '2018-01-15 21:15:38');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('17', '<p>Ini <strong>foto profil</strong> yang saya gunakan..</p>', '5211aff0c51086eeb4a101acd5be2f6c.jpeg', '000000000', '3F071963A7', '0', '2018-01-21 18:24:19', '2018-01-21 18:24:19');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('18', '<p>Diharap <strong>Ketua Kelas</strong> &nbsp;mengkoordinir kelasnya agar segera mengumpulkan fotocopy rapot semester 1-5 di meja saya.</p>', '', '909090909090', '3F071963A7', '3', '2018-01-21 21:16:50', '2018-01-21 21:28:41');


#
# TABLE STRUCTURE FOR: komentar
#

DROP TABLE IF EXISTS `komentar`;

CREATE TABLE `komentar` (
  `id_komentar` int(11) NOT NULL AUTO_INCREMENT,
  `isi_komentar` text NOT NULL,
  `id_informasi` int(11) NOT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_komentar`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('5', 'titip sendal...', '14', '111111111', 'C028D15CE3', '2018-01-14 15:42:03');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('6', 'Opo seh? gak jelas...', '14', '999999999999', 'C028D15CE3', '2018-01-14 15:51:30');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('7', 'hidup kerang ajaib!! \r\nlulululul...', '10', '111111111', 'C028D15CE3', '2018-01-14 17:23:24');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('8', 'Geje mesti..', '10', '999999999999', 'C028D15CE3', '2018-01-14 17:24:08');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('9', 'Harap dikondisikan!!', '10', 'hexa', '24101999', '2018-01-15 08:26:55');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('10', 'test notif', '14', '999999999999', 'C028D15CE3', '2018-01-15 11:50:25');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('11', 'opo ae bos', '14', '111111111', 'C028D15CE3', '2018-01-15 11:59:13');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('13', 'Laksanakan!', '15', '999999999999', 'C028D15CE3', '2018-01-15 21:04:01');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('14', 'wes ngerti', '16', '999999999999', 'C028D15CE3', '2018-01-15 21:18:11');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('15', 'wkwkwkw', '16', '111111111', 'C028D15CE3', '2018-01-21 13:19:08');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('16', 'GG..', '17', '000000000', '3F071963A7', '2018-01-21 18:24:40');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('17', 'Nice Pict!', '17', '909090909090', '3F071963A7', '2018-01-21 18:25:20');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('18', 'ngomong ae iki...', '16', '999999999999', 'C028D15CE3', '2018-01-22 09:10:19');


#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `message` varchar(255) NOT NULL,
  `link` varchar(100) NOT NULL,
  `icon` varchar(40) NOT NULL,
  `color` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('9', '999999999999', 'C028D15CE3', 'Telah menambahkan ruang R-13', 'MasterRuang', 'mdi-home-variant', 'success', '2018-01-04 08:47:08');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('10', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Ketua Kelas', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 08:17:12');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('11', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Sekertaris Absensi', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 08:48:05');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('12', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Sekertaris Absensi', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 08:48:05');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('13', '999999999999', 'C028D15CE3', 'Telah menghapus jabatan Sekertaris Absensi', 'MasterJabatan', 'mdi-ruler', 'danger', '2018-01-07 08:48:16');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('14', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Sekertaris Jurnal', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 08:48:45');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('15', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Bendahara Kas', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 15:00:03');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('16', '999999999999', 'C028D15CE3', 'Telah menambahkan jabatan Bendahara Tabungan', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-07 15:00:27');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('17', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Sekertaris Jurnal', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-07 16:01:34');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('18', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Anggota', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-07 16:01:47');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('19', '999999999999', 'C028D15CE3', 'Telah mengkonfirmasiAlex sebagai anggota kelas', 'MasterSiswa', 'mdi-account-check', 'success', '2018-01-07 16:07:40');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('20', '222222222', 'C028D15CE3', 'Telah bergabung ke kelas.', 'MasterSiswa', 'mdi-account-multiple-plus', 'success', '2018-01-07 19:23:03');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('21', '999999999999', 'C028D15CE3', 'Telah mengkonfirmasi Dicky%20Bayu%20Sadewa sebagai anggota kelas', 'MasterSiswa', 'mdi-account-check', 'success', '2018-01-07 19:25:45');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('22', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Ketua Kelas', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-07 19:59:21');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('23', '999999999999', 'C028D15CE3', 'Telah menambahkan ruang Lab-9', 'MasterRuang', 'mdi-home-variant', 'success', '2018-01-07 19:59:51');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('24', '999999999999', 'C028D15CE3', 'Telah menambahkan matapelajaran Bahasa Indonesia', 'MasterMatapelajaran', 'mdi-book-open-page-variant', 'success', '2018-01-07 20:00:06');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('25', '999999999999', 'C028D15CE3', 'Telah mengedit jabatan Sekertaris Absens', 'MasterJabatan', 'mdi-ruler', 'warning', '2018-01-07 20:00:29');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('26', '999999999999', 'C028D15CE3', 'Telah mengedit jabatan Sekertaris Jurnals', 'MasterJabatan', 'mdi-ruler', 'warning', '2018-01-07 20:01:29');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('27', '999999999999', 'C028D15CE3', 'Telah mengedit jabatan Sekertaris Jurnal', 'MasterJabatan', 'mdi-ruler', 'warning', '2018-01-07 20:03:37');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('28', '999999999999', 'C028D15CE3', 'Telah mengedit jabatan Sekertaris Absensi', 'MasterJabatan', 'mdi-ruler', 'warning', '2018-01-07 20:03:53');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('29', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Anggota', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-07 20:16:45');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('30', '999999999999', 'C028D15CE3', 'Telah menghapus Dicky Bayu Sadewa dari anggota kelas', 'MasterSiswa', 'mdi-account-minus', 'danger', '2018-01-07 22:26:48');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('31', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Ketua Kelas', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-09 20:47:24');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('32', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Anggota', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-09 20:48:01');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('33', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-11 14:07:36');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('34', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-11 20:39:28');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('35', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-11 21:40:29');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('36', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-11 21:44:30');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('37', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-11 21:46:20');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('38', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-11 21:50:24');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('39', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-11 21:51:07');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('40', '999999999999', 'C028D15CE3', 'Telah memperbarui informasi', 'LihatInformasi', 'mdi-information-variant', 'warning', '2018-01-12 04:18:49');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('41', '999999999999', 'C028D15CE3', 'Telah memperbarui informasi', 'LihatInformasi', 'mdi-information-variant', 'warning', '2018-01-12 04:20:15');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('42', '999999999999', 'C028D15CE3', 'Telah memperbarui informasi', 'LihatInformasi', 'mdi-information-variant', 'warning', '2018-01-12 04:20:24');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('43', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-14 11:30:27');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('44', '999999999999', 'C028D15CE3', 'Telah memperbarui informasi', 'LihatInformasi', 'mdi-information-variant', 'warning', '2018-01-14 11:31:06');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('45', '999999999999', 'C028D15CE3', 'Telah memperbarui informasi', 'LihatInformasi', 'mdi-information-variant', 'warning', '2018-01-14 11:32:54');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('46', '999999999999', 'C028D15CE3', 'Telah menghapus informasi yang dibuat Ida Fitriyaningsih', 'DataInformasi', 'mdi-information-variant', 'danger', '2018-01-14 11:44:37');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('47', '999999999999', 'C028D15CE3', 'Telah menghapus informasi yang dibuat Ida Fitriyaningsih', 'DataInformasi', 'mdi-information-variant', 'danger', '2018-01-14 11:44:43');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('48', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-14 12:32:58');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('49', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-14 12:33:15');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('50', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-14 12:34:32');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('51', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-14 13:58:43');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('52', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi', 'mdi-information-variant', 'success', '2018-01-14 14:03:10');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('53', '999999999999', 'C028D15CE3', 'Telah mengomentari sebuah postingan', 'LihatInformasi/info/14', 'mdi-comment-alert', 'warning', '2018-01-15 11:50:25');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('54', '111111111', 'C028D15CE3', 'Telah mengomentari sebuah postingan', 'LihatInformasi/info/14', 'mdi-comment-alert', 'warning', '2018-01-15 11:59:13');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('55', '999999999999', 'C028D15CE3', 'Telah memperbarui informasi', 'LihatInformasi/info/13', 'mdi-information-variant', 'warning', '2018-01-15 20:55:14');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('56', '999999999999', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi/info/15', 'mdi-information-variant', 'success', '2018-01-15 21:03:10');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('57', '111111111', 'C028D15CE3', 'Telah mengomentari sebuah postingan', 'LihatInformasi/info/15', 'mdi-comment-alert', 'warning', '2018-01-15 21:03:41');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('58', '999999999999', 'C028D15CE3', 'Telah mengomentari sebuah postingan', 'LihatInformasi/info/15', 'mdi-comment-alert', 'warning', '2018-01-15 21:04:01');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('59', '111111111', 'C028D15CE3', 'Telah menghapus komentar pada sebuah postingan', 'LihatInformasi/info/15', 'mdi-comment-alert', 'danger', '2018-01-15 21:09:29');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('60', '999999999999', 'C028D15CE3', 'Telah merubah Alex menjadi Ketua Kelas', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-15 21:11:31');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('61', '111111111', 'C028D15CE3', 'Telah menambahkan informasi baru', 'LihatInformasi/info/16', 'mdi-information-variant', 'success', '2018-01-15 21:15:38');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('62', '999999999999', 'C028D15CE3', 'Telah mengomentari sebuah postingan', 'LihatInformasi/info/16', 'mdi-comment-alert', 'warning', '2018-01-15 21:18:11');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('63', '7777777777777777', 'C028D15CE3', 'Telah bergabung ke kelas.', 'MasterWaliMurid', 'mdi-account-multiple-plus', 'success', '2018-01-19 22:46:45');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('64', '111111111', 'C028D15CE3', 'Telah mengomentari sebuah postingan', 'LihatInformasi/info/16', 'mdi-comment-alert', 'warning', '2018-01-21 13:19:08');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('65', '999999999999', 'C028D15CE3', 'Telah mengkonfirmasi Maria sebagai Wali murid', 'MasterSiswa', 'mdi-account-check', 'success', '2018-01-21 13:24:01');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('66', '999999999999', 'C028D15CE3', 'Telah menghapus Maria dari anggota kelas', 'MasterWaliMurid', 'mdi-account-minus', 'danger', '2018-01-21 14:40:32');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('67', '7777777777777777', 'C028D15CE3', 'Telah bergabung ke kelas.', 'MasterWaliMurid', 'mdi-account-multiple-plus', 'success', '2018-01-21 14:50:11');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('68', '000000000', '3F071963A7', 'Telah bergabung ke kelas.', 'MasterSiswa', 'mdi-account-multiple-plus', 'success', '2018-01-21 18:10:18');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('70', '909090909090', '3F071963A7', 'Telah mengkonfirmasi Abdur Rachman Wahed sebagai anggota kelas', 'MasterSiswa', 'mdi-account-check', 'success', '2018-01-21 18:17:52');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('71', '909090909090', '3F071963A7', 'Telah menambahkan jabatan Ketua Kelas', 'MasterJabatan', 'mdi-ruler', 'success', '2018-01-21 18:22:02');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('72', '909090909090', '3F071963A7', 'Telah merubah Abdur Rachman Wahed menjadi Ketua Kelas', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-01-21 18:22:24');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('73', '000000000', '3F071963A7', 'Telah menambahkan informasi baru', 'LihatInformasi/info/17', 'mdi-information-variant', 'success', '2018-01-21 18:24:19');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('74', '000000000', '3F071963A7', 'Telah mengomentari sebuah postingan', 'LihatInformasi/info/17', 'mdi-comment-alert', 'warning', '2018-01-21 18:24:40');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('75', '909090909090', '3F071963A7', 'Telah mengomentari sebuah postingan', 'LihatInformasi-info-17', 'mdi-comment-alert', 'warning', '2018-01-21 18:25:20');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('76', '9999999999999999', '3F071963A7', 'Telah bergabung ke kelas.', 'MasterWaliMurid', 'mdi-account-multiple-plus', 'success', '2018-01-21 18:28:43');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('77', '909090909090', '3F071963A7', 'Telah mengkonfirmasi Maria sebagai Wali murid', 'MasterWaliMurid', 'mdi-account-check', 'success', '2018-01-21 18:29:14');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('78', '909090909090', '3F071963A7', 'Telah menambahkan informasi baru', 'LihatInformasi/info/18', 'mdi-information-variant', 'success', '2018-01-21 21:16:50');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('79', '909090909090', '3F071963A7', 'Telah memperbarui informasi', 'LihatInformasi-info-18', 'mdi-information-variant', 'warning', '2018-01-21 21:28:41');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('80', '999999999999', 'C028D15CE3', 'Telah mengomentari sebuah postingan', 'LihatInformasi/info/16', 'mdi-comment-alert', 'warning', '2018-01-22 09:10:19');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('81', '999999999999', 'C028D15CE3', 'Telah menambahkan data guru baru', 'MasterGuru', 'mdi-account-card-details', 'success', '2018-01-25 18:05:06');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('82', '999999999999', 'C028D15CE3', 'Telah menambahkan data guru baru', 'MasterGuru', 'mdi-account-card-details', 'success', '2018-01-25 18:10:32');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('83', '999999999999', 'C028D15CE3', 'Telah menambahkan data guru baru', 'MasterGuru', 'mdi-account-card-details', 'success', '2018-01-26 17:49:33');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('84', '999999999999', 'C028D15CE3', 'Telah mengedit data guru test', 'MasterGuru', 'mdi-account-card-details', 'warning', '2018-01-26 18:52:29');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('85', '999999999999', 'C028D15CE3', 'Telah menghapus data guru dengan nama test', 'MasterGuru', 'mdi-account-card-details', 'danger', '2018-01-26 21:37:00');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('86', '999999999999', 'C028D15CE3', 'Telah menghapus data guru dengan nama test', 'MasterGuru', 'mdi-account-card-details', 'danger', '2018-01-26 21:37:00');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('87', '999999999999', 'C028D15CE3', 'Telah menghapus data guru dengan nama test', 'MasterGuru', 'mdi-account-card-details', 'danger', '2018-01-26 21:39:39');


#
# TABLE STRUCTURE FOR: logs_detail
#

DROP TABLE IF EXISTS `logs_detail`;

CREATE TABLE `logs_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_logs` int(11) NOT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;

INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('6', '9', '111111111', 'C028D15CE3', '2018-01-04 08:47:46');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('7', '10', '111111111', 'C028D15CE3', '2018-01-07 08:50:55');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('8', '12', '111111111', 'C028D15CE3', '2018-01-07 08:51:02');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('9', '11', '111111111', 'C028D15CE3', '2018-01-07 08:51:06');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('10', '13', '111111111', 'C028D15CE3', '2018-01-07 08:51:08');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('11', '14', '111111111', 'C028D15CE3', '2018-01-07 08:51:11');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('12', '15', '111111111', 'C028D15CE3', '2018-01-07 16:08:16');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('13', '16', '111111111', 'C028D15CE3', '2018-01-07 16:08:24');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('14', '19', '111111111', 'C028D15CE3', '2018-01-07 16:08:34');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('15', '18', '111111111', 'C028D15CE3', '2018-01-07 16:08:39');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('16', '17', '111111111', 'C028D15CE3', '2018-01-07 16:08:44');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('17', '20', '999999999999', 'C028D15CE3', '2018-01-07 19:25:31');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('18', '21', '111111111', 'C028D15CE3', '2018-01-07 19:43:09');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('19', '20', '111111111', 'C028D15CE3', '2018-01-07 19:54:06');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('20', '28', '111111111', 'C028D15CE3', '2018-01-07 20:05:40');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('21', '27', '111111111', 'C028D15CE3', '2018-01-07 20:08:51');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('22', '25', '111111111', 'C028D15CE3', '2018-01-07 20:08:57');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('23', '26', '111111111', 'C028D15CE3', '2018-01-07 20:09:08');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('24', '24', '111111111', 'C028D15CE3', '2018-01-07 20:09:13');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('25', '23', '111111111', 'C028D15CE3', '2018-01-07 20:09:17');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('26', '22', '111111111', 'C028D15CE3', '2018-01-07 20:09:24');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('27', '28', '222222222', 'C028D15CE3', '2018-01-07 20:10:25');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('28', '27', '222222222', 'C028D15CE3', '2018-01-07 20:10:29');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('29', '26', '222222222', 'C028D15CE3', '2018-01-07 20:10:32');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('30', '25', '222222222', 'C028D15CE3', '2018-01-07 20:10:36');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('31', '24', '222222222', 'C028D15CE3', '2018-01-07 20:10:39');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('32', '23', '222222222', 'C028D15CE3', '2018-01-07 20:10:43');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('33', '22', '222222222', 'C028D15CE3', '2018-01-07 20:10:46');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('34', '21', '222222222', 'C028D15CE3', '2018-01-07 20:10:51');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('35', '19', '222222222', 'C028D15CE3', '2018-01-07 20:10:59');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('36', '18', '222222222', 'C028D15CE3', '2018-01-07 20:11:03');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('37', '17', '222222222', 'C028D15CE3', '2018-01-07 20:11:07');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('38', '16', '222222222', 'C028D15CE3', '2018-01-07 20:11:12');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('39', '15', '222222222', 'C028D15CE3', '2018-01-07 20:11:15');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('40', '14', '222222222', 'C028D15CE3', '2018-01-07 20:11:19');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('41', '13', '222222222', 'C028D15CE3', '2018-01-07 20:11:23');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('42', '11', '222222222', 'C028D15CE3', '2018-01-07 20:11:27');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('43', '12', '222222222', 'C028D15CE3', '2018-01-07 20:11:31');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('44', '10', '222222222', 'C028D15CE3', '2018-01-07 20:11:35');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('45', '9', '222222222', 'C028D15CE3', '2018-01-07 20:11:39');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('46', '29', '111111111', 'C028D15CE3', '2018-01-07 20:17:20');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('47', '29', '222222222', 'C028D15CE3', '2018-01-07 20:17:58');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('48', '30', '111111111', 'C028D15CE3', '2018-01-07 22:28:00');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('49', '31', '111111111', 'C028D15CE3', '2018-01-09 20:47:41');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('50', '32', '111111111', 'C028D15CE3', '2018-01-09 20:48:18');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('51', '52', '111111111', 'C028D15CE3', '2018-01-14 17:21:31');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('53', '53', '111111111', 'C028D15CE3', '2018-01-15 11:58:45');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('54', '40', '111111111', 'C028D15CE3', '2018-01-15 12:04:20');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('55', '51', '111111111', 'C028D15CE3', '2018-01-15 12:04:27');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('56', '50', '111111111', 'C028D15CE3', '2018-01-15 12:04:39');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('57', '49', '111111111', 'C028D15CE3', '2018-01-15 12:04:44');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('58', '48', '111111111', 'C028D15CE3', '2018-01-15 12:04:48');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('59', '47', '111111111', 'C028D15CE3', '2018-01-15 12:04:51');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('60', '46', '111111111', 'C028D15CE3', '2018-01-15 12:04:55');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('61', '45', '111111111', 'C028D15CE3', '2018-01-15 12:04:58');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('62', '44', '111111111', 'C028D15CE3', '2018-01-15 12:05:02');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('63', '43', '111111111', 'C028D15CE3', '2018-01-15 12:05:09');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('64', '42', '111111111', 'C028D15CE3', '2018-01-15 12:05:12');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('65', '41', '111111111', 'C028D15CE3', '2018-01-15 12:05:15');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('66', '39', '111111111', 'C028D15CE3', '2018-01-15 12:05:19');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('67', '38', '111111111', 'C028D15CE3', '2018-01-15 12:05:22');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('68', '37', '111111111', 'C028D15CE3', '2018-01-15 12:05:25');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('69', '36', '111111111', 'C028D15CE3', '2018-01-15 12:05:29');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('70', '35', '111111111', 'C028D15CE3', '2018-01-15 12:05:32');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('71', '34', '111111111', 'C028D15CE3', '2018-01-15 12:05:35');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('72', '33', '111111111', 'C028D15CE3', '2018-01-15 12:05:39');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('73', '54', '999999999999', 'C028D15CE3', '2018-01-15 20:55:41');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('74', '55', '111111111', 'C028D15CE3', '2018-01-15 20:58:02');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('75', '56', '111111111', 'C028D15CE3', '2018-01-15 21:03:27');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('76', '57', '999999999999', 'C028D15CE3', '2018-01-15 21:03:51');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('77', '58', '111111111', 'C028D15CE3', '2018-01-15 21:07:48');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('78', '59', '999999999999', 'C028D15CE3', '2018-01-15 21:09:44');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('79', '59', '999999999999', 'C028D15CE3', '2018-01-15 21:09:44');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('80', '60', '111111111', 'C028D15CE3', '2018-01-15 21:12:03');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('81', '61', '999999999999', 'C028D15CE3', '2018-01-15 21:15:51');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('82', '62', '111111111', 'C028D15CE3', '2018-01-15 21:18:23');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('83', '64', '999999999999', 'C028D15CE3', '2018-01-21 13:19:31');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('84', '65', '111111111', 'C028D15CE3', '2018-01-21 13:24:17');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('85', '66', '111111111', 'C028D15CE3', '2018-01-21 14:42:22');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('86', '68', '909090909090', '3F071963A7', '2018-01-21 18:10:59');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('87', '69', '000000000', '3F071963A7', '2018-01-21 18:13:14');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('88', '70', '000000000', '3F071963A7', '2018-01-21 18:18:10');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('89', '74', '909090909090', '3F071963A7', '2018-01-21 18:25:02');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('90', '76', '909090909090', '3F071963A7', '2018-01-21 18:29:05');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('91', '73', '909090909090', '3F071963A7', '2018-01-21 20:24:20');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('92', '78', '9999999999999999', '3F071963A7', '2018-01-21 21:18:07');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('93', '0', '000000000', '3F071963A7', '2018-01-21 21:21:26');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('94', '80', '111111111', 'C028D15CE3', '2018-01-22 09:10:50');


#
# TABLE STRUCTURE FOR: master_guru
#

DROP TABLE IF EXISTS `master_guru`;

CREATE TABLE `master_guru` (
  `kode_guru` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(50) NOT NULL,
  `NIP` varchar(20) NOT NULL,
  `nama_guru` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_guru`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `master_guru` (`kode_guru`, `kode_kelas`, `NIP`, `nama_guru`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('2', 'C028D15CE3', '123123123123', 'Siti Cholifah', 'Perempuan', 'Surabaya', '1972-01-25', 'Jl. Simo', '+628-176-248-1624', 'c956e035c2c0565125002cb15b9c19f2.jpg', '2018-01-25 18:10:32', '2018-01-25 18:10:32');


#
# TABLE STRUCTURE FOR: master_jabatan
#

DROP TABLE IF EXISTS `master_jabatan`;

CREATE TABLE `master_jabatan` (
  `kode_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `akses_jabatan` int(11) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `jabatan` varchar(40) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_jabatan`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('1', '1', '24101999', 'CEO', 'CEO setClass', '2017-12-10 12:03:22', '2017-12-10 12:03:22');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('3', '2', 'ED147B54C8', 'Wali Kelas', 'Wali Kelas', '2017-12-10 12:23:58', '2017-12-10 12:23:58');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('9', '2', 'C028D15CE3', 'Wali Kelas', 'Wali Kelas', '2017-12-13 20:55:50', '2017-12-13 20:55:50');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('16', '2', '527002B1F3', 'Wali Kelas', 'Wali Kelas', '2017-12-30 18:07:50', '2017-12-30 18:07:50');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('25', '6', 'C028D15CE3', 'Anggota', 'Anggota kelas', '2018-01-01 21:26:50', '2018-01-11 21:15:08');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('26', '3', 'C028D15CE3', 'Ketua Kelas', 'Mengkoordinir kelas', '2018-01-07 08:17:12', '2018-01-07 08:17:12');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('28', '4', 'C028D15CE3', 'Sekertaris Absensi', 'Mengatur absensi kelas', '2018-01-07 08:48:05', '2018-01-07 20:03:53');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('29', '4', 'C028D15CE3', 'Sekertaris Jurnal', 'Mengatur jurnal kelas', '2018-01-07 08:48:45', '2018-01-07 20:03:37');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('30', '5', 'C028D15CE3', 'Bendahara Kas', 'Mengatur kas kelas', '2018-01-07 15:00:03', '2018-01-07 15:00:03');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('31', '5', 'C028D15CE3', 'Bendahara Tabungan', 'Mengatur tabungan kelas', '2018-01-07 15:00:26', '2018-01-07 15:00:26');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('35', '6', '3F071963A7', 'Anggota', 'Anggota kelas', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('36', '7', '3F071963A7', 'Wali Murid', 'Wali Murid', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('37', '2', '3F071963A7', 'Wali Kelas', 'Wali Kelas', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('38', '3', '3F071963A7', 'Ketua Kelas', 'Mengkoordinir kelas', '2018-01-21 18:22:02', '2018-01-21 18:22:02');


#
# TABLE STRUCTURE FOR: master_kelas
#

DROP TABLE IF EXISTS `master_kelas`;

CREATE TABLE `master_kelas` (
  `kode_kelas` varchar(50) NOT NULL,
  `nama_sekolah` varchar(40) NOT NULL,
  `alamat_sekolah` varchar(250) NOT NULL,
  `telp_sekolah` varchar(30) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `jurusan` varchar(40) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('3F071963A7', 'SDN Manukan Wetan 2', 'Jl. Sikatan', '+031-827-359-2735', '6 SD', '', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('527002B1F3', 'Smkn 2 Surabaya', 'Jl. Patua', '03191281723', '3 SMA/SMK', 'Rekayasa Perangkat Lunak', '2017-12-30 18:07:50', '2017-12-30 18:07:50');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('C028D15CE3', 'Smkn 2 Surabaya', 'Jl. Patua', '03191281723', '3 SMA/SMK', 'Rekayasa Perangkat Lunak', '2017-12-13 19:05:00', '2017-12-13 19:05:00');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('ED147B54C8', 'Smkn 2 Surabaya', 'Jl. Patua', '03134753458', '3 SMA/SMK', 'RPL', '2017-12-03 18:50:26', '2017-12-10 10:02:02');


#
# TABLE STRUCTURE FOR: master_login
#

DROP TABLE IF EXISTS `master_login`;

CREATE TABLE `master_login` (
  `kode_user` varchar(20) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_jabatan` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_user`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('000000000', '3', '3F071963A7', '38', 'wahed@gmail.com', 'Abdur Rachman Wahed', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', 'a609309b761d44a78d88d5d35fe31adf.jpeg', '2018-01-21 18:10:18', '2018-01-21 18:22:24');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('111111111', '3', 'C028D15CE3', '26', 'alex@gmail.com', 'Alex', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '5d8f4f81804a6fc9bec063a6dd500747.jpeg', '2018-01-01 22:02:54', '2018-01-15 21:11:31');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('111111111111', '2', '527002B1F3', '16', 'nailmuna@gmail.com', 'Nailil Muna', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '85a64515235d57f04822a7baaf6a3fc5.png', '2017-12-30 18:07:50', '2017-12-31 23:44:39');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('764134813461', '2', 'ED147B54C8', '3', 'suwondo@gmail.com', 'Suwondo', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', 'default-profile.png', '2017-12-03 18:50:26', '2017-12-31 23:44:42');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('909090909090', '2', '3F071963A7', '37', 'rini@gmail.com', 'Rini Umbarani', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '9d089d60e22ff31be34ee2901836bc60.jpg', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('999999999999', '2', 'C028D15CE3', '9', 'fitriyaningsihida@yahoo.co.id', 'Ida Fitriyaningsih', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '0f856bc17a07c673e657fb996cd7993f.jpg', '2017-12-13 19:05:01', '2017-12-31 23:44:44');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('9999999999999999', '4', '3F071963A7', '36', 'maria@gmail.com', 'Maria', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '24cef5da2777434d71e434aad72e217a.jpg', '2018-01-21 18:28:43', '2018-01-21 20:43:48');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('hexa', '1', '24101999', '1', 'abdurrachmanwahed@gmail.com', 'Abdur Rachman Wahed', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', 'default-profile.png', '2017-11-27 10:16:29', '2018-01-21 18:17:26');


#
# TABLE STRUCTURE FOR: master_matapelajaran
#

DROP TABLE IF EXISTS `master_matapelajaran`;

CREATE TABLE `master_matapelajaran` (
  `kode_matapelajaran` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(50) NOT NULL,
  `nama_matapelajaran` varchar(40) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_matapelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `master_matapelajaran` (`kode_matapelajaran`, `kode_kelas`, `nama_matapelajaran`, `created_at`, `updated_at`) VALUES ('1', 'C028D15CE3', 'Matematika', '2017-12-30 09:59:40', '2017-12-30 10:23:19');
INSERT INTO `master_matapelajaran` (`kode_matapelajaran`, `kode_kelas`, `nama_matapelajaran`, `created_at`, `updated_at`) VALUES ('2', '527002B1F3', 'Matematika', '2018-01-03 20:56:55', '2018-01-03 20:56:55');
INSERT INTO `master_matapelajaran` (`kode_matapelajaran`, `kode_kelas`, `nama_matapelajaran`, `created_at`, `updated_at`) VALUES ('3', 'C028D15CE3', 'Bahasa Indonesia', '2018-01-07 20:00:06', '2018-01-07 20:00:06');


#
# TABLE STRUCTURE FOR: master_ruang
#

DROP TABLE IF EXISTS `master_ruang`;

CREATE TABLE `master_ruang` (
  `kode_ruang` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(50) NOT NULL,
  `nama_ruang` varchar(40) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_ruang`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('2', 'C028D15CE3', 'R-21', '2017-12-30 10:56:43', '2017-12-30 10:56:43');
INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('3', '527002B1F3', 'R -21', '2018-01-03 20:56:01', '2018-01-03 20:56:01');
INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('4', 'C028D15CE3', 'R-13', '2018-01-04 08:47:08', '2018-01-04 08:47:08');
INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('5', 'C028D15CE3', 'Lab-9', '2018-01-07 19:59:51', '2018-01-07 19:59:51');


#
# TABLE STRUCTURE FOR: master_siswa
#

DROP TABLE IF EXISTS `master_siswa`;

CREATE TABLE `master_siswa` (
  `NIS` varchar(20) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `NIK` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`NIS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('000000000', '3F071963A7', '3', 'wahed@gmail.com', '0000000000000000', 'Abdur Rachman Wahed', 'Laki Laki', 'Surabaya', '1999-10-24', 'Perum UKA', '+628-197-249-8172', 'a609309b761d44a78d88d5d35fe31adf.jpeg', '2018-01-21 18:10:18', '2018-01-21 18:10:18');
INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('111111111', 'C028D15CE3', '3', 'alex@gmail.com', '1111111111111111', 'Alex', 'Laki Laki', 'Surabaya', '1999-10-24', 'Jl. Manukan Kasman No. 1/36', '+628-897-498-1793', '5d8f4f81804a6fc9bec063a6dd500747.jpeg', '2018-01-01 22:02:54', '2018-01-07 22:34:35');


#
# TABLE STRUCTURE FOR: master_wali_kelas
#

DROP TABLE IF EXISTS `master_wali_kelas`;

CREATE TABLE `master_wali_kelas` (
  `NIP` varchar(20) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`NIP`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('111111111111', '527002B1F3', '2', 'nailmuna@gmail.com', 'Nailil Muna', 'Perempuan', 'Surabaya', '1972-01-08', 'Jl. Uka Gang 18', '+628-769-821-7389', '85a64515235d57f04822a7baaf6a3fc5.png', '2017-12-30 18:07:50', '2017-12-30 18:07:50');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('764134813461', 'ED147B54C8', '2', 'suwondo@gmail.com', 'Suwondo', 'Laki Laki', 'Surabaya', '1969-10-18', 'Manukan Kulon', '+628-768-612-3846', '', '2017-12-03 18:50:26', '2017-12-30 08:34:05');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('909090909090', '3F071963A7', '2', 'rini@gmail.com', 'Rini Umbarani', 'Perempuan', 'Surabaya', '1971-01-21', 'Jl. Simo Rukun', '+628-109-872-3940', '9d089d60e22ff31be34ee2901836bc60.jpg', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('999999999999', 'C028D15CE3', '2', 'fitriyaningsihida@yahoo.co.id', 'Ida Fitriyaningsih', 'Perempuan', 'Surabaya', '1972-11-25', 'Jl. Kandangan', '+628-871-239-1231', '0f856bc17a07c673e657fb996cd7993f.jpg', '2017-12-13 19:05:01', '2018-01-11 07:30:12');


#
# TABLE STRUCTURE FOR: master_wali_murid
#

DROP TABLE IF EXISTS `master_wali_murid`;

CREATE TABLE `master_wali_murid` (
  `NIK` varchar(20) NOT NULL,
  `NIK_siswa` varchar(20) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `hubungan_dengan_siswa` varchar(50) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`NIK`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_wali_murid` (`NIK`, `NIK_siswa`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `hubungan_dengan_siswa`, `foto`, `created_at`, `updated_at`) VALUES ('7777777777777777', '1111111111111111', 'C028D15CE3', '4', 'maria@gmail.com', 'Maria', 'Perempuan', 'Surabaya', '1969-01-21', 'Jl. Manukan Kasman', '+628-193-889-9660', 'Anak Kandung', '413fab2c074e828209b17668f45b45ca.jpg', '2018-01-21 14:50:11', '2018-01-21 14:50:11');
INSERT INTO `master_wali_murid` (`NIK`, `NIK_siswa`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `hubungan_dengan_siswa`, `foto`, `created_at`, `updated_at`) VALUES ('9999999999999999', '0000000000000000', '3F071963A7', '4', 'maria@gmail.com', 'Maria', 'Perempuan', 'Surabaya', '1972-01-21', 'Perum UKA', '+628-187-249-8172', 'Anak Kandung', '24cef5da2777434d71e434aad72e217a.jpg', '2018-01-21 18:28:42', '2018-01-21 20:43:48');


#
# TABLE STRUCTURE FOR: menu_child
#

DROP TABLE IF EXISTS `menu_child`;

CREATE TABLE `menu_child` (
  `kode_menu_child` int(11) NOT NULL AUTO_INCREMENT,
  `kode_menu_header` int(11) NOT NULL,
  `menu_name` varchar(20) NOT NULL,
  `file_php` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_menu_child`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('4', '1', 'Menu Header', 'MenuHeader', '2017-12-05 21:09:47', '2017-12-05 21:09:47');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('5', '1', 'Menu Child', 'MenuChild', '2017-12-05 21:10:04', '2017-12-05 21:10:04');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('9', '1', 'Hak Akses', 'HakAkses', '2017-12-10 10:11:50', '2017-12-10 10:11:50');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('11', '1', 'Menu Level', 'MenuLevel', '2017-12-11 20:13:47', '2017-12-11 20:13:47');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('12', '1', 'Profil', 'UserProfile', '2017-12-26 11:23:06', '2017-12-26 19:03:02');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('13', '2', 'Master Jabatan', 'MasterJabatan', '2017-12-27 21:35:55', '2017-12-27 21:35:55');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('14', '2', 'Master Matapelajaran', 'MasterMatapelajaran', '2017-12-30 09:47:16', '2017-12-30 09:47:16');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('15', '2', 'Master Ruang', 'MasterRuang', '2017-12-30 10:53:05', '2017-12-30 10:53:05');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('17', '2', 'Master Siswa', 'MasterSiswa', '2018-01-07 06:48:44', '2018-01-07 06:48:44');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('18', '3', 'Data Informasi', 'DataInformasi', '2018-01-09 20:12:58', '2018-01-09 22:47:46');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('19', '3', 'Lihat Informasi', 'LihatInformasi', '2018-01-14 18:54:19', '2018-01-14 18:54:19');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('20', '2', 'Master Wali Murid', 'MasterWaliMurid', '2018-01-21 07:56:52', '2018-01-21 07:56:52');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('21', '2', 'Master Guru', 'MasterGuru', '2018-01-24 02:37:36', '2018-01-24 02:37:36');


#
# TABLE STRUCTURE FOR: menu_hak_akses
#

DROP TABLE IF EXISTS `menu_hak_akses`;

CREATE TABLE `menu_hak_akses` (
  `kode_akses` int(11) NOT NULL AUTO_INCREMENT,
  `hak_akses` varchar(30) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_akses`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('1', 'hexa', 'CEO setClass', '2017-12-10 09:53:28', '2017-12-10 15:57:28');
INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('2', 'Wali Kelas', 'Wali kelas', '2017-12-10 11:08:34', '2017-12-10 15:57:54');
INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('3', 'Siswa', 'Anggota kelas', '2017-12-10 11:11:06', '2017-12-31 14:22:30');
INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('4', 'Wali Murid', 'Orang tua murid', '2017-12-10 15:48:23', '2018-01-19 22:52:01');


#
# TABLE STRUCTURE FOR: menu_header
#

DROP TABLE IF EXISTS `menu_header`;

CREATE TABLE `menu_header` (
  `kode_menu_header` int(11) NOT NULL AUTO_INCREMENT,
  `menu_header` varchar(20) NOT NULL,
  `icon` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_menu_header`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('1', 'Pengaturan', 'fa fa-wrench', '2017-12-04 16:55:32', '2017-12-04 16:55:32');
INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('2', 'Master', 'fa fa-archive', '2017-12-04 16:55:42', '2017-12-04 16:55:42');
INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('3', 'Informasi', 'fa fa-bell', '2018-01-09 20:11:55', '2018-01-09 20:11:55');


#
# TABLE STRUCTURE FOR: menu_level
#

DROP TABLE IF EXISTS `menu_level`;

CREATE TABLE `menu_level` (
  `kode_menu_level` int(11) NOT NULL AUTO_INCREMENT,
  `kode_akses` int(11) NOT NULL,
  `kode_menu_child` int(11) NOT NULL,
  `akses_insert` tinyint(1) NOT NULL,
  `akses_view` tinyint(1) NOT NULL,
  `akses_edit` tinyint(1) NOT NULL,
  `akses_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`kode_menu_level`)
) ENGINE=InnoDB AUTO_INCREMENT=575 DEFAULT CHARSET=latin1;

INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('523', '1', '4', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('524', '1', '5', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('525', '1', '9', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('526', '1', '11', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('527', '1', '12', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('528', '1', '13', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('529', '1', '14', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('530', '1', '15', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('531', '1', '17', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('532', '1', '18', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('533', '1', '19', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('534', '1', '20', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('535', '1', '21', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('536', '2', '4', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('537', '2', '5', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('538', '2', '9', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('539', '2', '11', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('540', '2', '12', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('541', '2', '13', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('542', '2', '14', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('543', '2', '15', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('544', '2', '17', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('545', '2', '18', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('546', '2', '19', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('547', '2', '20', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('548', '2', '21', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('549', '3', '4', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('550', '3', '5', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('551', '3', '9', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('552', '3', '11', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('553', '3', '12', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('554', '3', '13', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('555', '3', '14', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('556', '3', '15', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('557', '3', '17', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('558', '3', '18', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('559', '3', '19', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('560', '3', '20', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('561', '3', '21', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('562', '4', '4', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('563', '4', '5', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('564', '4', '9', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('565', '4', '11', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('566', '4', '12', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('567', '4', '13', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('568', '4', '14', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('569', '4', '15', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('570', '4', '17', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('571', '4', '18', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('572', '4', '19', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('573', '4', '20', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('574', '4', '21', '0', '1', '0', '0');


