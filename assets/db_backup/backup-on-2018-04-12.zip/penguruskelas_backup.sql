#
# TABLE STRUCTURE FOR: data_absensi
#

DROP TABLE IF EXISTS `data_absensi`;

CREATE TABLE `data_absensi` (
  `kode_absensi` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`kode_absensi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `data_absensi` (`kode_absensi`, `kode_kelas`, `tanggal`) VALUES ('AK/C028D15CE3/09042018', 'C028D15CE3', '2018-04-09');
INSERT INTO `data_absensi` (`kode_absensi`, `kode_kelas`, `tanggal`) VALUES ('AK/C028D15CE3/11022018', 'C028D15CE3', '2018-02-11');
INSERT INTO `data_absensi` (`kode_absensi`, `kode_kelas`, `tanggal`) VALUES ('AK/C028D15CE3/12022018', 'C028D15CE3', '2018-02-12');
INSERT INTO `data_absensi` (`kode_absensi`, `kode_kelas`, `tanggal`) VALUES ('AK/C028D15CE3/16022018', 'C028D15CE3', '2018-02-16');
INSERT INTO `data_absensi` (`kode_absensi`, `kode_kelas`, `tanggal`) VALUES ('AK/DF23214FB6/11042018', 'DF23214FB6', '2018-04-11');
INSERT INTO `data_absensi` (`kode_absensi`, `kode_kelas`, `tanggal`) VALUES ('AK/DF23214FB6/12042018', 'DF23214FB6', '2018-04-12');


#
# TABLE STRUCTURE FOR: data_absensi_detail
#

DROP TABLE IF EXISTS `data_absensi_detail`;

CREATE TABLE `data_absensi_detail` (
  `id_detail` int(11) NOT NULL AUTO_INCREMENT,
  `kode_absensi` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_user` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO `data_absensi_detail` (`id_detail`, `kode_absensi`, `kode_kelas`, `kode_user`, `status`, `created_at`, `updated_at`) VALUES ('10', 'AK/C028D15CE3/11022018', 'C028D15CE3', '111111111', 'Masuk', '2018-02-11 22:05:25', '2018-04-10 01:06:20');
INSERT INTO `data_absensi_detail` (`id_detail`, `kode_absensi`, `kode_kelas`, `kode_user`, `status`, `created_at`, `updated_at`) VALUES ('11', 'AK/C028D15CE3/11022018', 'C028D15CE3', '123456789', 'Sakit', '2018-02-11 22:05:25', '2018-04-10 01:06:21');
INSERT INTO `data_absensi_detail` (`id_detail`, `kode_absensi`, `kode_kelas`, `kode_user`, `status`, `created_at`, `updated_at`) VALUES ('12', 'AK/C028D15CE3/12022018', 'C028D15CE3', '111111111', 'Masuk', '2018-02-12 22:06:48', '2018-02-12 22:06:48');
INSERT INTO `data_absensi_detail` (`id_detail`, `kode_absensi`, `kode_kelas`, `kode_user`, `status`, `created_at`, `updated_at`) VALUES ('13', 'AK/C028D15CE3/12022018', 'C028D15CE3', '123456789', 'Masuk', '2018-02-12 22:06:48', '2018-02-12 22:06:48');
INSERT INTO `data_absensi_detail` (`id_detail`, `kode_absensi`, `kode_kelas`, `kode_user`, `status`, `created_at`, `updated_at`) VALUES ('26', 'AK/C028D15CE3/16022018', 'C028D15CE3', '111111111', 'Tidak Masuk', '2018-02-16 16:34:22', '2018-02-16 16:34:22');
INSERT INTO `data_absensi_detail` (`id_detail`, `kode_absensi`, `kode_kelas`, `kode_user`, `status`, `created_at`, `updated_at`) VALUES ('27', 'AK/C028D15CE3/16022018', 'C028D15CE3', '123456789', 'Tidak Masuk', '2018-02-16 16:34:22', '2018-02-16 16:34:22');
INSERT INTO `data_absensi_detail` (`id_detail`, `kode_absensi`, `kode_kelas`, `kode_user`, `status`, `created_at`, `updated_at`) VALUES ('28', 'AK/DF23214FB6/11042018', 'DF23214FB6', '444444444', 'Masuk', '2018-04-11 15:32:44', '2018-04-11 15:32:44');
INSERT INTO `data_absensi_detail` (`id_detail`, `kode_absensi`, `kode_kelas`, `kode_user`, `status`, `created_at`, `updated_at`) VALUES ('29', 'AK/DF23214FB6/12042018', 'DF23214FB6', '444444444', 'Tidak Masuk', '2018-04-12 15:34:32', '2018-04-12 15:34:32');


#
# TABLE STRUCTURE FOR: data_informasi
#

DROP TABLE IF EXISTS `data_informasi`;

CREATE TABLE `data_informasi` (
  `id_informasi` int(11) NOT NULL AUTO_INCREMENT,
  `isi_informasi` text NOT NULL,
  `gambar` varchar(100) DEFAULT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `akses_jabatan` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_informasi`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('8', '<p>aaaaaa<strong>aaaaaaaaaaa</strong>aaaaas</p>', 'ecb9c9116be2e65a64384ad797fda0b0.jpeg', '999999999999', 'C028D15CE3', '4', '2018-01-11 21:51:07', '2018-01-12 04:20:24');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('10', '<p>aaaaaaaaaaaaaaaaaaa</p>', '', '999999999999', 'C028D15CE3', '0', '2018-01-14 12:32:58', '2018-01-14 12:32:58');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('11', '<p>aaaaaaaaaaaaaaaaaaaaaaaaaaaa</p>', '', '999999999999', 'C028D15CE3', '3', '2018-01-14 12:33:15', '2018-01-14 12:33:15');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('12', '<p>aaaaaaaaaaaaaaaaaaaaaaaaa</p>', '', '999999999999', 'C028D15CE3', '5', '2018-01-14 12:34:32', '2018-01-14 12:34:32');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('13', '<p>Ini desain <strong>poster&nbsp;untuk kelas</strong>..<br />gimana? ada saran?</p>', 'c0e2e9e9f2e45ed8655a158e8d6b860c.jpg', '999999999999', 'C028D15CE3', '0', '2018-01-14 13:58:43', '2018-01-15 20:55:14');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('14', '<p>tetstafytsaskdjalslgvasfd</p>', '9757af6236a321c3fbf123021a257df5.jpeg', '999999999999', 'C028D15CE3', '3', '2018-01-14 14:03:10', '2018-01-14 14:03:10');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('15', '<p><span style=\"color: #ff0000;\"><strong>Anak anak</strong></span> ini namanya spedo meter..<br />diharap anak anak bisa mendesain sedemikian rupa..</p>', '7aaf7ce97f7b7eb7a2b8a6f5aeeec65d.png', '999999999999', 'C028D15CE3', '0', '2018-01-15 21:03:10', '2018-01-15 21:03:10');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('16', '<p>Contoh surat ..</p>', 'e2174ac8fb4ecee0e2a3e83e1324a1df.jpg', '111111111', 'C028D15CE3', '0', '2018-01-15 21:15:38', '2018-01-15 21:15:38');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('17', '<p>Ini <strong>foto profil</strong> yang saya gunakan..</p>', '5211aff0c51086eeb4a101acd5be2f6c.jpeg', '000000000', '3F071963A7', '0', '2018-01-21 18:24:19', '2018-01-21 18:24:19');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('18', '<p>Diharap <strong>Ketua Kelas</strong> &nbsp;mengkoordinir kelasnya agar segera mengumpulkan fotocopy rapot semester 1-5 di meja saya.</p>', '', '909090909090', '3F071963A7', '3', '2018-01-21 21:16:50', '2018-01-21 21:28:41');
INSERT INTO `data_informasi` (`id_informasi`, `isi_informasi`, `gambar`, `kode_user`, `kode_kelas`, `akses_jabatan`, `created_at`, `updated_at`) VALUES ('19', '<p>Jadi hari ini aku ukk gays..</p>', '', '111111111', 'C028D15CE3', '0', '2018-04-10 12:57:28', '2018-04-10 12:57:28');


#
# TABLE STRUCTURE FOR: data_jadwal_mapel
#

DROP TABLE IF EXISTS `data_jadwal_mapel`;

CREATE TABLE `data_jadwal_mapel` (
  `kode_jadwal` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(50) NOT NULL,
  `NIP` varchar(20) NOT NULL,
  `kode_matapelajaran` int(11) NOT NULL,
  `kode_ruang` int(11) NOT NULL,
  `hari` int(2) NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_jadwal`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `data_jadwal_mapel` (`kode_jadwal`, `kode_kelas`, `NIP`, `kode_matapelajaran`, `kode_ruang`, `hari`, `jam_mulai`, `jam_selesai`, `created_at`, `updated_at`) VALUES ('7', 'C028D15CE3', '123123123123', '3', '4', '3', '12:00:00', '15:15:00', '2018-04-08 08:19:21', '2018-04-08 08:19:21');
INSERT INTO `data_jadwal_mapel` (`kode_jadwal`, `kode_kelas`, `NIP`, `kode_matapelajaran`, `kode_ruang`, `hari`, `jam_mulai`, `jam_selesai`, `created_at`, `updated_at`) VALUES ('8', 'C028D15CE3', '123123123123', '3', '4', '3', '16:20:00', '05:30:00', '2018-04-09 00:42:17', '2018-04-09 00:42:17');
INSERT INTO `data_jadwal_mapel` (`kode_jadwal`, `kode_kelas`, `NIP`, `kode_matapelajaran`, `kode_ruang`, `hari`, `jam_mulai`, `jam_selesai`, `created_at`, `updated_at`) VALUES ('9', 'C028D15CE3', '123123123123', '1', '4', '4', '09:01:00', '17:01:00', '2018-04-09 01:01:27', '2018-04-09 01:01:27');
INSERT INTO `data_jadwal_mapel` (`kode_jadwal`, `kode_kelas`, `NIP`, `kode_matapelajaran`, `kode_ruang`, `hari`, `jam_mulai`, `jam_selesai`, `created_at`, `updated_at`) VALUES ('10', 'C028D15CE3', '123123123123', '1', '2', '1', '01:15:00', '01:15:00', '2018-04-09 01:15:45', '2018-04-09 01:15:45');
INSERT INTO `data_jadwal_mapel` (`kode_jadwal`, `kode_kelas`, `NIP`, `kode_matapelajaran`, `kode_ruang`, `hari`, `jam_mulai`, `jam_selesai`, `created_at`, `updated_at`) VALUES ('11', 'C028D15CE3', '123123123123', '1', '2', '2', '12:54:00', '12:54:00', '2018-04-10 12:54:10', '2018-04-10 12:54:10');


#
# TABLE STRUCTURE FOR: data_tabungan
#

DROP TABLE IF EXISTS `data_tabungan`;

CREATE TABLE `data_tabungan` (
  `kode_tabungan` varchar(50) NOT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `penerima` varchar(50) NOT NULL,
  `nominal` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_tabungan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `data_tabungan` (`kode_tabungan`, `kode_user`, `kode_kelas`, `penerima`, `nominal`, `created_at`, `updated_at`) VALUES ('T/3F071963A7/20180128/1', '000000000', '3F071963A7', '909090909090', '12500', '2018-01-28 21:26:22', '2018-01-28 21:26:22');
INSERT INTO `data_tabungan` (`kode_tabungan`, `kode_user`, `kode_kelas`, `penerima`, `nominal`, `created_at`, `updated_at`) VALUES ('T/3F071963A7/20180128/2', '222222222', '3F071963A7', '000000000', '50000', '2018-01-28 21:39:50', '2018-01-28 21:39:50');
INSERT INTO `data_tabungan` (`kode_tabungan`, `kode_user`, `kode_kelas`, `penerima`, `nominal`, `created_at`, `updated_at`) VALUES ('T/C028D15CE3/20180129/1', '111111111', 'C028D15CE3', '999999999999', '1000', '2018-01-29 09:42:58', '2018-01-29 09:42:58');
INSERT INTO `data_tabungan` (`kode_tabungan`, `kode_user`, `kode_kelas`, `penerima`, `nominal`, `created_at`, `updated_at`) VALUES ('T/C028D15CE3/20180129/2', '111111111', 'C028D15CE3', '111111111', '12500', '2018-01-29 07:16:49', '2018-01-29 07:24:18');
INSERT INTO `data_tabungan` (`kode_tabungan`, `kode_user`, `kode_kelas`, `penerima`, `nominal`, `created_at`, `updated_at`) VALUES ('T/C028D15CE3/20180129/3', '123456789', 'C028D15CE3', '111111111', '10000', '2018-01-29 09:48:16', '2018-01-29 09:48:16');


#
# TABLE STRUCTURE FOR: kas_keluar
#

DROP TABLE IF EXISTS `kas_keluar`;

CREATE TABLE `kas_keluar` (
  `kode_kas_keluar` varchar(50) NOT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `nominal` double NOT NULL,
  `perihal` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_kas_keluar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `kas_keluar` (`kode_kas_keluar`, `kode_user`, `kode_kelas`, `nominal`, `perihal`, `created_at`, `updated_at`) VALUES ('KK/3F071963A7/20180128/1', '000000000', '3F071963A7', '15000', 'Membeli vas bunga', '2018-01-28 21:29:35', '2018-01-28 21:29:35');
INSERT INTO `kas_keluar` (`kode_kas_keluar`, `kode_user`, `kode_kelas`, `nominal`, `perihal`, `created_at`, `updated_at`) VALUES ('KK/C028D15CE3/20180128/1', '111111111', 'C028D15CE3', '5000', 'Membeli spidol', '2018-01-28 20:23:05', '2018-01-28 20:32:29');


#
# TABLE STRUCTURE FOR: kas_masuk
#

DROP TABLE IF EXISTS `kas_masuk`;

CREATE TABLE `kas_masuk` (
  `kode_kas_masuk` varchar(50) NOT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `penerima` varchar(50) NOT NULL,
  `nominal` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_kas_masuk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `kas_masuk` (`kode_kas_masuk`, `kode_user`, `kode_kelas`, `penerima`, `nominal`, `created_at`, `updated_at`) VALUES ('KM/3F071963A7/20180128/1', '000000000', '3F071963A7', '000000000', '25000', '2018-01-28 21:28:32', '2018-01-28 21:28:32');
INSERT INTO `kas_masuk` (`kode_kas_masuk`, `kode_user`, `kode_kelas`, `penerima`, `nominal`, `created_at`, `updated_at`) VALUES ('KM/3F071963A7/20180128/2', '222222222', '3F071963A7', '000000000', '10000', '2018-01-28 21:39:01', '2018-01-28 21:39:01');
INSERT INTO `kas_masuk` (`kode_kas_masuk`, `kode_user`, `kode_kelas`, `penerima`, `nominal`, `created_at`, `updated_at`) VALUES ('KM/C028D15CE3/20180128/1', '111111111', 'C028D15CE3', '111111111', '50000', '2018-01-28 18:51:35', '2018-01-28 18:51:35');
INSERT INTO `kas_masuk` (`kode_kas_masuk`, `kode_user`, `kode_kelas`, `penerima`, `nominal`, `created_at`, `updated_at`) VALUES ('KM/C028D15CE3/20180129/2', '123456789', 'C028D15CE3', '111111111', '100000', '2018-01-29 09:45:21', '2018-01-29 09:45:21');


#
# TABLE STRUCTURE FOR: komentar
#

DROP TABLE IF EXISTS `komentar`;

CREATE TABLE `komentar` (
  `id_komentar` int(11) NOT NULL AUTO_INCREMENT,
  `isi_komentar` text NOT NULL,
  `id_informasi` int(11) NOT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_komentar`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('5', 'titip sendal...', '14', '111111111', 'C028D15CE3', '2018-01-14 15:42:03');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('6', 'Opo seh? gak jelas...', '14', '999999999999', 'C028D15CE3', '2018-01-14 15:51:30');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('7', 'hidup kerang ajaib!! \r\nlulululul...', '10', '111111111', 'C028D15CE3', '2018-01-14 17:23:24');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('8', 'Geje mesti..', '10', '999999999999', 'C028D15CE3', '2018-01-14 17:24:08');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('9', 'Harap dikondisikan!!', '10', 'hexa', '24101999', '2018-01-15 08:26:55');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('10', 'test notif', '14', '999999999999', 'C028D15CE3', '2018-01-15 11:50:25');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('11', 'opo ae bos', '14', '111111111', 'C028D15CE3', '2018-01-15 11:59:13');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('13', 'Laksanakan!', '15', '999999999999', 'C028D15CE3', '2018-01-15 21:04:01');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('14', 'wes ngerti', '16', '999999999999', 'C028D15CE3', '2018-01-15 21:18:11');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('15', 'wkwkwkw', '16', '111111111', 'C028D15CE3', '2018-01-21 13:19:08');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('16', 'GG..', '17', '000000000', '3F071963A7', '2018-01-21 18:24:40');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('17', 'Nice Pict!', '17', '909090909090', '3F071963A7', '2018-01-21 18:25:20');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('18', 'ngomong ae iki...', '16', '999999999999', 'C028D15CE3', '2018-01-22 09:10:19');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('19', 'Coba\r\npakai bl2br..', '16', '999999999999', 'C028D15CE3', '2018-01-29 09:30:44');
INSERT INTO `komentar` (`id_komentar`, `isi_komentar`, `id_informasi`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('20', 'adv', '16', '999999999999', 'C028D15CE3', '2018-04-10 01:17:14');


#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `message` varchar(255) NOT NULL,
  `link` varchar(100) NOT NULL,
  `icon` varchar(40) NOT NULL,
  `color` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('1', '999999999991', 'DF23214FB6', 'Telah menambahkan data guru baru', 'MasterGuru', 'mdi-account-card-details', 'success', '2018-04-11 15:23:23');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('2', '555555555', '38CEE3AFBD', 'Telah bergabung ke kelas.', 'MasterSiswa', 'mdi-account-multiple-plus', 'success', '2018-04-11 15:26:29');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('3', '444444444', 'DF23214FB6', 'Telah bergabung ke kelas.', 'MasterSiswa', 'mdi-account-multiple-plus', 'success', '2018-04-11 15:29:14');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('4', '999999999991', 'DF23214FB6', 'Telah mengkonfirmasi asdasdas sebagai anggota kelas', 'MasterSiswa', 'mdi-account-check', 'success', '2018-04-11 15:29:46');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('5', '999999999991', 'DF23214FB6', 'Telah menambahkan jabatan Sekertaris absen', 'MasterJabatan', 'mdi-ruler', 'success', '2018-04-11 15:30:24');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('6', '999999999991', 'DF23214FB6', 'Telah merubah asdasdas menjadi Sekertaris absen', 'MasterSiswa', 'mdi-account-edit', 'warning', '2018-04-11 15:30:44');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('7', '444444444', 'DF23214FB6', 'asdasdas sedang mengabsen', 'AbsensiKelas', 'mdi-book-open', 'success', '2018-04-11 15:32:32');
INSERT INTO `logs` (`id`, `kode_user`, `kode_kelas`, `message`, `link`, `icon`, `color`, `created_at`) VALUES ('8', '444444444', 'DF23214FB6', 'asdasdas sedang mengabsen', 'AbsensiKelas', 'mdi-book-open', 'success', '2018-04-12 15:34:27');


#
# TABLE STRUCTURE FOR: logs_detail
#

DROP TABLE IF EXISTS `logs_detail`;

CREATE TABLE `logs_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_logs` int(11) NOT NULL,
  `kode_user` varchar(50) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('1', '3', '999999999991', 'DF23214FB6', '2018-04-11 15:29:36');
INSERT INTO `logs_detail` (`id`, `id_logs`, `kode_user`, `kode_kelas`, `created_at`) VALUES ('2', '6', '444444444', 'DF23214FB6', '2018-04-11 15:31:09');


#
# TABLE STRUCTURE FOR: master_guru
#

DROP TABLE IF EXISTS `master_guru`;

CREATE TABLE `master_guru` (
  `kode_guru` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(50) NOT NULL,
  `NIP` varchar(20) NOT NULL,
  `nama_guru` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_guru`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `master_guru` (`kode_guru`, `kode_kelas`, `NIP`, `nama_guru`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('2', 'C028D15CE3', '123123123123', 'Siti Cholifah', 'Perempuan', 'Surabaya', '1972-01-25', 'Jl. Simo', '+628-176-248-1624', 'c956e035c2c0565125002cb15b9c19f2.jpg', '2018-01-25 18:10:32', '2018-01-25 18:10:32');
INSERT INTO `master_guru` (`kode_guru`, `kode_kelas`, `NIP`, `nama_guru`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('3', 'DF23214FB6', '123123123124', 'asdasd', 'Perempuan', 'asdasdasd', '2018-04-11', 'asdasdasd', '+628-252-352-35', 'aa949a17d851c3faddb66e7914631f98.jpg', '2018-04-11 15:23:23', '2018-04-11 15:23:23');


#
# TABLE STRUCTURE FOR: master_jabatan
#

DROP TABLE IF EXISTS `master_jabatan`;

CREATE TABLE `master_jabatan` (
  `kode_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `akses_jabatan` int(11) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `jabatan` varchar(40) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_jabatan`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('1', '1', '24101999', 'CEO', 'CEO setClass', '2017-12-10 12:03:22', '2017-12-10 12:03:22');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('3', '2', 'ED147B54C8', 'Wali Kelas', 'Wali Kelas', '2017-12-10 12:23:58', '2017-12-10 12:23:58');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('9', '2', 'C028D15CE3', 'Wali Kelas', 'Wali Kelas', '2017-12-13 20:55:50', '2017-12-13 20:55:50');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('16', '2', '527002B1F3', 'Wali Kelas', 'Wali Kelas', '2017-12-30 18:07:50', '2017-12-30 18:07:50');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('25', '6', 'C028D15CE3', 'Anggota', 'Anggota kelas', '2018-01-01 21:26:50', '2018-01-11 21:15:08');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('26', '3', 'C028D15CE3', 'Ketua Kelas', 'Mengkoordinir kelas', '2018-01-07 08:17:12', '2018-01-07 08:17:12');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('28', '4', 'C028D15CE3', 'Sekertaris Absensi', 'Mengatur absensi kelas', '2018-01-07 08:48:05', '2018-01-07 20:03:53');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('29', '4', 'C028D15CE3', 'Sekertaris Jurnal', 'Mengatur jurnal kelas', '2018-01-07 08:48:45', '2018-01-07 20:03:37');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('30', '5', 'C028D15CE3', 'Bendahara Kas', 'Mengatur kas kelas', '2018-01-07 15:00:03', '2018-01-07 15:00:03');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('31', '5', 'C028D15CE3', 'Bendahara Tabungan', 'Mengatur tabungan kelas', '2018-01-07 15:00:26', '2018-01-07 15:00:26');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('35', '6', '3F071963A7', 'Anggota', 'Anggota kelas', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('36', '7', '3F071963A7', 'Wali Murid', 'Wali Murid', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('37', '2', '3F071963A7', 'Wali Kelas', 'Wali Kelas', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('38', '3', '3F071963A7', 'Ketua Kelas', 'Mengkoordinir kelas', '2018-01-21 18:22:02', '2018-01-21 18:22:02');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('39', '5', '3F071963A7', 'Bendahara Kas', 'Mengatur kas kelas', '2018-01-28 21:27:21', '2018-01-28 21:27:21');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('40', '7', 'C028D15CE3', 'Wali Murid', 'Wali Murid', '2018-01-29 07:45:09', '2018-01-29 07:45:30');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('41', '6', '38CEE3AFBD', 'Anggota', 'Anggota kelas', '2018-01-29 11:17:55', '2018-01-29 11:17:55');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('42', '7', '38CEE3AFBD', 'Wali Murid', 'Wali Murid', '2018-01-29 11:17:55', '2018-01-29 11:17:55');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('43', '2', '38CEE3AFBD', 'Wali Kelas', 'Wali Kelas', '2018-01-29 11:17:55', '2018-01-29 11:17:55');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('44', '3', '38CEE3AFBD', 'Ketua Kelas', 'Mengkoordinir kelas\r\n', '2018-01-29 11:20:40', '2018-01-29 11:20:40');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('45', '6', 'DF23214FB6', 'Anggota', 'Anggota kelas', '2018-04-11 15:21:08', '2018-04-11 15:21:08');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('46', '7', 'DF23214FB6', 'Wali Murid', 'Wali Murid', '2018-04-11 15:21:08', '2018-04-11 15:21:08');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('47', '2', 'DF23214FB6', 'Wali Kelas', 'Wali Kelas', '2018-04-11 15:21:08', '2018-04-11 15:21:08');
INSERT INTO `master_jabatan` (`kode_jabatan`, `akses_jabatan`, `kode_kelas`, `jabatan`, `keterangan`, `created_at`, `updated_at`) VALUES ('48', '4', 'DF23214FB6', 'Sekertaris absen', 'asdasda', '2018-04-11 15:30:24', '2018-04-11 15:30:24');


#
# TABLE STRUCTURE FOR: master_kelas
#

DROP TABLE IF EXISTS `master_kelas`;

CREATE TABLE `master_kelas` (
  `kode_kelas` varchar(50) NOT NULL,
  `nama_sekolah` varchar(40) NOT NULL,
  `alamat_sekolah` varchar(250) NOT NULL,
  `telp_sekolah` varchar(30) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `jurusan` varchar(40) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('38CEE3AFBD', 'Smkn 2 Surabaya', 'Jl. Patua', '+031-918-230-1823', '3 SMP', '', '2018-01-29 11:17:55', '2018-01-29 11:17:55');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('3F071963A7', 'SDN Manukan Wetan 2', 'Jl. Sikatan', '+031-827-359-2735', '6 SD', '', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('527002B1F3', 'Smkn 2 Surabaya', 'Jl. Patua', '03191281723', '3 SMA/SMK', 'Rekayasa Perangkat Lunak', '2017-12-30 18:07:50', '2017-12-30 18:07:50');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('C028D15CE3', 'Smkn 2 Surabaya', 'Jl. Patua', '03191281723', '3 SMA/SMK', 'Rekayasa Perangkat Lunak', '2017-12-13 19:05:00', '2017-12-13 19:05:00');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('DF23214FB6', 'SMKN @', 'aasdasd', '+031-102-901-9029', '3 SMP', '', '2018-04-11 15:21:08', '2018-04-11 15:21:08');
INSERT INTO `master_kelas` (`kode_kelas`, `nama_sekolah`, `alamat_sekolah`, `telp_sekolah`, `kelas`, `jurusan`, `created_at`, `updated_at`) VALUES ('ED147B54C8', 'Smkn 2 Surabaya', 'Jl. Patua', '03134753458', '3 SMA/SMK', 'RPL', '2017-12-03 18:50:26', '2017-12-10 10:02:02');


#
# TABLE STRUCTURE FOR: master_login
#

DROP TABLE IF EXISTS `master_login`;

CREATE TABLE `master_login` (
  `kode_user` varchar(20) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_jabatan` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_user`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('000000000', '3', '3F071963A7', '39', 'wahed@gmail.com', 'Abdur Rachman Wahed', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', 'a609309b761d44a78d88d5d35fe31adf.jpeg', '2018-01-21 18:10:18', '2018-01-28 21:27:41');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('111111111', '3', 'C028D15CE3', '31', 'alex@gmail.com', 'Alex', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '5d8f4f81804a6fc9bec063a6dd500747.jpeg', '2018-01-01 22:02:54', '2018-04-11 08:48:51');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('111111111111', '2', '527002B1F3', '16', 'nailmuna@gmail.com', 'Nailil Muna', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '85a64515235d57f04822a7baaf6a3fc5.png', '2017-12-30 18:07:50', '2017-12-31 23:44:39');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('123112312', '3', 'C028D15CE3', '25', 'arvenaloverz@gmail.com', 'sasdasdasd', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '727cc6282a2ac01d567e2d2fbf42a74b.jpg', '2018-04-11 09:00:31', '2018-04-11 09:01:15');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('123456789', '3', 'C028D15CE3', '26', 'sukmakrisna66@gmail.com', 'krisna sukma perdana', '5e63153545a3a70cd501064adf891721', 'Confirmed', '7854c8f83ed76b275256e979b901490f.jpg', '2018-01-29 07:32:31', '2018-01-29 11:23:12');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('222222222', '3', '3F071963A7', '35', 'hun@gmail.com', 'Dicky Bayu Sadewa', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '4fc7bd4067917dbdfd4080b5a7a09402.jpg', '2018-01-28 21:34:26', '2018-01-28 21:34:46');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('444444444', '3', 'DF23214FB6', '48', 'aa@g.com', 'asdasdas', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '1d7ed714be48b0ec0473452295b1d2ae.jpg', '2018-04-11 15:29:14', '2018-04-11 15:30:44');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('4444444444444444', '4', 'C028D15CE3', '40', 'didikkurniawan@gmail.com', 'Didik Kurniawan', '3e6253057393d92aa3e7e987aac25a9a', 'Confirmed', '4081ce6dfb79e5e1d13a5feb53a27f96.jpg', '2018-01-29 07:45:44', '2018-01-29 07:46:18');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('555555555', '3', '38CEE3AFBD', '41', 'a@g.com', 'hajhJADH', '21d158ae4db6e8b3a45b85aab3d28c47', 'Unconfirmed', 'a94400cd3d6f777479c813f1751a4ab9.jpg', '2018-04-11 15:26:29', '2018-04-11 15:26:29');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('764134813461', '2', 'ED147B54C8', '3', 'suwondo@gmail.com', 'Suwondo', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', 'default-profile.png', '2017-12-03 18:50:26', '2017-12-31 23:44:42');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('909090909090', '2', '3F071963A7', '37', 'rini@gmail.com', 'Rini Umbarani', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '9d089d60e22ff31be34ee2901836bc60.jpg', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('909090909091', '2', '38CEE3AFBD', '43', 'guru@gmail.com', 'Guru', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '6ddef597d8dce165853f25d2284e8fbd.jpg', '2018-01-29 11:17:56', '2018-01-29 11:17:56');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('999999999991', '2', 'DF23214FB6', '47', 'tester@gmail.com', 'TesterGuru', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', 'd8786a69c3f62d40179cdd936ad0d1ec.jpg', '2018-04-11 15:21:09', '2018-04-11 15:21:09');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('999999999999', '2', 'C028D15CE3', '9', 'fitriyaningsihida@yahoo.co.id', 'Ida Fitriyaningsih', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '0f856bc17a07c673e657fb996cd7993f.jpg', '2017-12-13 19:05:01', '2017-12-31 23:44:44');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('9999999999999999', '4', 'C028D15CE3', '36', 'maria@gmail.com', 'Maria', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', '24cef5da2777434d71e434aad72e217a.jpg', '2018-01-21 18:28:43', '2018-02-13 23:09:42');
INSERT INTO `master_login` (`kode_user`, `kode_akses`, `kode_kelas`, `kode_jabatan`, `email`, `nama`, `password`, `status`, `foto`, `created_at`, `updated_at`) VALUES ('hexa', '1', '24101999', '1', 'abdurrachmanwahed@gmail.com', 'Abdur Rachman Wahed', '21d158ae4db6e8b3a45b85aab3d28c47', 'Confirmed', 'default-profile.png', '2017-11-27 10:16:29', '2018-01-21 18:17:26');


#
# TABLE STRUCTURE FOR: master_matapelajaran
#

DROP TABLE IF EXISTS `master_matapelajaran`;

CREATE TABLE `master_matapelajaran` (
  `kode_matapelajaran` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(50) NOT NULL,
  `nama_matapelajaran` varchar(40) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_matapelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `master_matapelajaran` (`kode_matapelajaran`, `kode_kelas`, `nama_matapelajaran`, `created_at`, `updated_at`) VALUES ('1', 'C028D15CE3', 'Matematika', '2017-12-30 09:59:40', '2017-12-30 10:23:19');
INSERT INTO `master_matapelajaran` (`kode_matapelajaran`, `kode_kelas`, `nama_matapelajaran`, `created_at`, `updated_at`) VALUES ('2', '527002B1F3', 'Matematika', '2018-01-03 20:56:55', '2018-01-03 20:56:55');
INSERT INTO `master_matapelajaran` (`kode_matapelajaran`, `kode_kelas`, `nama_matapelajaran`, `created_at`, `updated_at`) VALUES ('3', 'C028D15CE3', 'Bahasa Indonesia', '2018-01-07 20:00:06', '2018-01-07 20:00:06');


#
# TABLE STRUCTURE FOR: master_ruang
#

DROP TABLE IF EXISTS `master_ruang`;

CREATE TABLE `master_ruang` (
  `kode_ruang` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(50) NOT NULL,
  `nama_ruang` varchar(40) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_ruang`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('2', 'C028D15CE3', 'R-21', '2017-12-30 10:56:43', '2017-12-30 10:56:43');
INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('3', '527002B1F3', 'R -21', '2018-01-03 20:56:01', '2018-01-03 20:56:01');
INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('4', 'C028D15CE3', 'R-13', '2018-01-04 08:47:08', '2018-01-04 08:47:08');
INSERT INTO `master_ruang` (`kode_ruang`, `kode_kelas`, `nama_ruang`, `created_at`, `updated_at`) VALUES ('5', 'C028D15CE3', 'Lab-9', '2018-01-07 19:59:51', '2018-01-07 19:59:51');


#
# TABLE STRUCTURE FOR: master_siswa
#

DROP TABLE IF EXISTS `master_siswa`;

CREATE TABLE `master_siswa` (
  `NIS` varchar(20) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `NIK` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`NIS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('000000000', '3F071963A7', '3', 'wahed@gmail.com', '0000000000000000', 'Abdur Rachman Wahed', 'Laki Laki', 'Surabaya', '1999-10-24', 'Perum UKA', '+628-197-249-8172', 'a609309b761d44a78d88d5d35fe31adf.jpeg', '2018-01-21 18:10:18', '2018-01-21 18:10:18');
INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('111111111', 'C028D15CE3', '3', 'alex@gmail.com', '1111111111111111', 'Alex', 'Laki Laki', 'Surabaya', '1999-10-24', 'Jl. Manukan Kasman No. 1/36', '+628-897-498-1793', '5d8f4f81804a6fc9bec063a6dd500747.jpeg', '2018-01-01 22:02:54', '2018-02-16 16:31:00');
INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('123112312', 'C028D15CE3', '3', 'arvenaloverz@gmail.com', '1231241241411231', 'sasdasdasd', 'Laki Laki', 'asdasd', '2018-04-11', '121241dasd', '+628-123-123-124', '727cc6282a2ac01d567e2d2fbf42a74b.jpg', '2018-04-11 09:00:31', '2018-04-11 09:00:31');
INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('123456789', 'C028D15CE3', '3', 'sukmakrisna66@gmail.com', '1011121314115161', 'krisna sukma perdana', 'Laki Laki', 'Surabaya', '2000-06-27', 'Jl. Dupak baru no.10', '+628-121-713-9792', '7854c8f83ed76b275256e979b901490f.jpg', '2018-01-29 07:32:31', '2018-01-29 07:32:31');
INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('222222222', '3F071963A7', '3', 'hun@gmail.com', '2222222222222222', 'Dicky Bayu Sadewa', 'Laki Laki', 'Surabaya', '1999-01-28', 'Jl. Kandangan', '+628-891-729-3871', '4fc7bd4067917dbdfd4080b5a7a09402.jpg', '2018-01-28 21:34:26', '2018-01-28 21:34:26');
INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('444444444', 'DF23214FB6', '3', 'aa@g.com', '4444444444444444', 'asdasdas', 'Laki Laki', 'asdas', '2018-04-11', 'asdasda', '+628-123-123-123', '1d7ed714be48b0ec0473452295b1d2ae.jpg', '2018-04-11 15:29:14', '2018-04-11 15:29:14');
INSERT INTO `master_siswa` (`NIS`, `kode_kelas`, `kode_akses`, `email`, `NIK`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('555555555', '38CEE3AFBD', '3', 'a@g.com', '5555555555555555', 'hajhJADH', 'Laki Laki', 'sas', '2018-04-11', 'asdasd', '+628-928-198-2391', 'a94400cd3d6f777479c813f1751a4ab9.jpg', '2018-04-11 15:26:29', '2018-04-11 15:26:29');


#
# TABLE STRUCTURE FOR: master_wali_kelas
#

DROP TABLE IF EXISTS `master_wali_kelas`;

CREATE TABLE `master_wali_kelas` (
  `NIP` varchar(20) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`NIP`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('111111111111', '527002B1F3', '2', 'nailmuna@gmail.com', 'Nailil Muna', 'Perempuan', 'Surabaya', '1972-01-08', 'Jl. Uka Gang 18', '+628-769-821-7389', '85a64515235d57f04822a7baaf6a3fc5.png', '2017-12-30 18:07:50', '2017-12-30 18:07:50');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('764134813461', 'ED147B54C8', '2', 'suwondo@gmail.com', 'Suwondo', 'Laki Laki', 'Surabaya', '1969-10-18', 'Manukan Kulon', '+628-768-612-3846', '', '2017-12-03 18:50:26', '2017-12-30 08:34:05');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('909090909090', '3F071963A7', '2', 'rini@gmail.com', 'Rini Umbarani', 'Perempuan', 'Surabaya', '1971-01-21', 'Jl. Simo Rukun', '+628-109-872-3940', '9d089d60e22ff31be34ee2901836bc60.jpg', '2018-01-21 18:05:29', '2018-01-21 18:05:29');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('909090909091', '38CEE3AFBD', '2', 'guru@gmail.com', 'Guru', 'Laki Laki', 'Surabaya', '2018-01-29', 'Jl. Kandangan', '+628-819-723-9719', '6ddef597d8dce165853f25d2284e8fbd.jpg', '2018-01-29 11:17:55', '2018-01-29 11:17:55');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('999999999991', 'DF23214FB6', '2', 'tester@gmail.com', 'TesterGuru', 'Perempuan', 'Surabaya', '2018-04-11', 'aksjdkajsda', '+628-192-891-8241', 'd8786a69c3f62d40179cdd936ad0d1ec.jpg', '2018-04-11 15:21:08', '2018-04-11 15:22:43');
INSERT INTO `master_wali_kelas` (`NIP`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `foto`, `created_at`, `updated_at`) VALUES ('999999999999', 'C028D15CE3', '2', 'fitriyaningsihida@yahoo.co.id', 'Ida Fitriyaningsih', 'Perempuan', 'Surabaya', '1972-11-25', 'Jl. Kandangan', '+628-871-239-1231', '0f856bc17a07c673e657fb996cd7993f.jpg', '2017-12-13 19:05:01', '2018-02-19 12:00:23');


#
# TABLE STRUCTURE FOR: master_wali_murid
#

DROP TABLE IF EXISTS `master_wali_murid`;

CREATE TABLE `master_wali_murid` (
  `NIK` varchar(20) NOT NULL,
  `NIK_siswa` varchar(20) NOT NULL,
  `kode_kelas` varchar(50) NOT NULL,
  `kode_akses` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `hubungan_dengan_siswa` varchar(50) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`NIK`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `master_wali_murid` (`NIK`, `NIK_siswa`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `hubungan_dengan_siswa`, `foto`, `created_at`, `updated_at`) VALUES ('4444444444444444', '1011121314115161', 'C028D15CE3', '4', 'didikkurniawan@gmail.com', 'Didik Kurniawan', 'Laki Laki', 'Surabaya', '1972-02-04', 'Jl. Dupak Baru No.10', '+628-123-499-9674', 'Anak Kandung', '4081ce6dfb79e5e1d13a5feb53a27f96.jpg', '2018-01-29 07:45:44', '2018-01-29 07:45:44');
INSERT INTO `master_wali_murid` (`NIK`, `NIK_siswa`, `kode_kelas`, `kode_akses`, `email`, `nama`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `no_telp`, `hubungan_dengan_siswa`, `foto`, `created_at`, `updated_at`) VALUES ('9999999999999999', '1111111111111111', 'C028D15CE3', '4', 'maria@gmail.com', 'Maria', 'Perempuan', 'Surabaya', '1969-01-21', 'Jl. Manukan Kasman', '+628-193-889-9660', 'Anak Kandung', '413fab2c074e828209b17668f45b45ca.jpg', '2018-01-21 14:50:11', '2018-02-13 23:10:24');


#
# TABLE STRUCTURE FOR: menu_child
#

DROP TABLE IF EXISTS `menu_child`;

CREATE TABLE `menu_child` (
  `kode_menu_child` int(11) NOT NULL AUTO_INCREMENT,
  `kode_menu_header` int(11) NOT NULL,
  `menu_name` varchar(20) NOT NULL,
  `file_php` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_menu_child`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('4', '1', 'Menu Header', 'MenuHeader', '2017-12-05 21:09:47', '2017-12-05 21:09:47');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('5', '1', 'Menu Child', 'MenuChild', '2017-12-05 21:10:04', '2017-12-05 21:10:04');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('9', '1', 'Hak Akses', 'HakAkses', '2017-12-10 10:11:50', '2017-12-10 10:11:50');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('11', '1', 'Menu Level', 'MenuLevel', '2017-12-11 20:13:47', '2017-12-11 20:13:47');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('12', '1', 'Profil', 'UserProfile', '2017-12-26 11:23:06', '2017-12-26 19:03:02');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('13', '2', 'Master Jabatan', 'MasterJabatan', '2017-12-27 21:35:55', '2017-12-27 21:35:55');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('14', '2', 'Master Matapelajaran', 'MasterMatapelajaran', '2017-12-30 09:47:16', '2017-12-30 09:47:16');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('15', '2', 'Master Ruang', 'MasterRuang', '2017-12-30 10:53:05', '2017-12-30 10:53:05');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('17', '2', 'Master Siswa', 'MasterSiswa', '2018-01-07 06:48:44', '2018-01-07 06:48:44');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('18', '3', 'Data Informasi', 'DataInformasi', '2018-01-09 20:12:58', '2018-01-09 22:47:46');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('19', '3', 'Lihat Informasi', 'LihatInformasi', '2018-01-14 18:54:19', '2018-01-14 18:54:19');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('20', '2', 'Master Wali Murid', 'MasterWaliMurid', '2018-01-21 07:56:52', '2018-01-21 07:56:52');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('21', '2', 'Master Guru', 'MasterGuru', '2018-01-24 02:37:36', '2018-01-24 02:37:36');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('22', '4', 'Tabungan Kelas', 'TabunganKelas', '2018-01-27 14:59:56', '2018-01-27 14:59:56');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('23', '4', 'Kas Masuk', 'KasMasuk', '2018-01-28 17:42:23', '2018-01-28 17:42:23');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('24', '4', 'Kas Keluar', 'KasKeluar', '2018-01-28 17:42:38', '2018-01-28 17:42:38');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('26', '6', 'Absensi Kelas', 'AbsensiKelas', '2018-02-05 09:21:38', '2018-02-05 09:21:38');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('27', '6', 'Jadwal Matapelajaran', 'JadwalMapel', '2018-04-07 13:06:11', '2018-04-07 13:06:11');
INSERT INTO `menu_child` (`kode_menu_child`, `kode_menu_header`, `menu_name`, `file_php`, `created_at`, `updated_at`) VALUES ('28', '7', 'child', 'menuBaru', '2018-04-12 15:37:30', '2018-04-12 15:37:30');


#
# TABLE STRUCTURE FOR: menu_hak_akses
#

DROP TABLE IF EXISTS `menu_hak_akses`;

CREATE TABLE `menu_hak_akses` (
  `kode_akses` int(11) NOT NULL AUTO_INCREMENT,
  `hak_akses` varchar(30) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_akses`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('1', 'hexa', 'CEO setClass', '2017-12-10 09:53:28', '2017-12-10 15:57:28');
INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('2', 'Wali Kelas', 'Wali kelas', '2017-12-10 11:08:34', '2017-12-10 15:57:54');
INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('3', 'Siswa', 'Anggota kelas', '2017-12-10 11:11:06', '2017-12-31 14:22:30');
INSERT INTO `menu_hak_akses` (`kode_akses`, `hak_akses`, `keterangan`, `created_at`, `updated_at`) VALUES ('4', 'Wali Murid', 'Orang tua murid', '2017-12-10 15:48:23', '2018-01-19 22:52:01');


#
# TABLE STRUCTURE FOR: menu_header
#

DROP TABLE IF EXISTS `menu_header`;

CREATE TABLE `menu_header` (
  `kode_menu_header` int(11) NOT NULL AUTO_INCREMENT,
  `menu_header` varchar(20) NOT NULL,
  `icon` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_menu_header`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('1', 'Pengaturan', 'fa fa-wrench', '2017-12-04 16:55:32', '2017-12-04 16:55:32');
INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('2', 'Master', 'fa fa-archive', '2017-12-04 16:55:42', '2017-12-04 16:55:42');
INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('3', 'Informasi', 'fa fa-bell', '2018-01-09 20:11:55', '2018-01-09 20:11:55');
INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('4', 'Keuangan', 'fa fa-money', '2018-01-27 14:58:41', '2018-01-27 14:58:41');
INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('6', 'Administrasi', 'fa fa-book', '2018-02-05 09:20:26', '2018-02-05 09:20:26');
INSERT INTO `menu_header` (`kode_menu_header`, `menu_header`, `icon`, `created_at`, `updated_at`) VALUES ('7', 'menuBaru', 'fa fa-calendar', '2018-04-12 15:36:41', '2018-04-12 15:36:41');


#
# TABLE STRUCTURE FOR: menu_level
#

DROP TABLE IF EXISTS `menu_level`;

CREATE TABLE `menu_level` (
  `kode_menu_level` int(11) NOT NULL AUTO_INCREMENT,
  `kode_akses` int(11) NOT NULL,
  `kode_menu_child` int(11) NOT NULL,
  `akses_insert` tinyint(1) NOT NULL,
  `akses_view` tinyint(1) NOT NULL,
  `akses_edit` tinyint(1) NOT NULL,
  `akses_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`kode_menu_level`)
) ENGINE=InnoDB AUTO_INCREMENT=924 DEFAULT CHARSET=latin1;

INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('851', '4', '4', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('852', '4', '5', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('853', '4', '9', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('854', '4', '11', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('855', '4', '12', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('856', '4', '13', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('857', '4', '14', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('858', '4', '15', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('859', '4', '17', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('860', '4', '18', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('861', '4', '19', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('862', '4', '20', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('863', '4', '21', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('864', '4', '22', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('865', '4', '23', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('866', '4', '24', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('867', '4', '26', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('868', '4', '27', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('869', '2', '4', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('870', '2', '5', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('871', '2', '9', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('872', '2', '11', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('873', '2', '12', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('874', '2', '13', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('875', '2', '14', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('876', '2', '15', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('877', '2', '17', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('878', '2', '18', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('879', '2', '19', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('880', '2', '20', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('881', '2', '21', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('882', '2', '22', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('883', '2', '23', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('884', '2', '24', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('885', '2', '26', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('886', '2', '27', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('887', '3', '4', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('888', '3', '5', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('889', '3', '9', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('890', '3', '11', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('891', '3', '12', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('892', '3', '13', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('893', '3', '14', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('894', '3', '15', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('895', '3', '17', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('896', '3', '18', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('897', '3', '19', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('898', '3', '20', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('899', '3', '21', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('900', '3', '22', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('901', '3', '23', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('902', '3', '24', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('903', '3', '26', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('904', '3', '27', '0', '1', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('905', '1', '4', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('906', '1', '5', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('907', '1', '9', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('908', '1', '11', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('909', '1', '12', '0', '0', '0', '0');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('910', '1', '13', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('911', '1', '14', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('912', '1', '15', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('913', '1', '17', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('914', '1', '18', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('915', '1', '19', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('916', '1', '20', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('917', '1', '21', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('918', '1', '22', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('919', '1', '23', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('920', '1', '24', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('921', '1', '26', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('922', '1', '27', '1', '1', '1', '1');
INSERT INTO `menu_level` (`kode_menu_level`, `kode_akses`, `kode_menu_child`, `akses_insert`, `akses_view`, `akses_edit`, `akses_delete`) VALUES ('923', '1', '28', '0', '1', '0', '0');


